/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : Wed Nov 22 09:15:30 CET 2000
    copyright            : (C) 2000 by 
    email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
using namespace std;

#include "vector3d.h"

int main(int argc, char *argv[])
{
  Vector3D a(1,2,3), b(4,5,6);

  cout << "a = " << a << endl;
  cout << "b = " << b << endl;
  cout << "NULVECT = " << Vector3D::NULVECT << endl;
  cout << "a+b = " << a+b << endl;
  cout << "a-b = " << a-b << endl;
  cout << "a*b = " << a*b << endl;
  cout << "a*b = " << smul(a,b) << endl;
  cout << "(a == b) = " << ((a == b)? "true": "false") << endl;
  cin >> a;
  cout << a;
  return 0;
}
