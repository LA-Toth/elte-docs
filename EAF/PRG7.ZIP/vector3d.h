/***************************************************************************
                          vector3d.h  -  description
                             -------------------
    begin                : Wed Nov 22 2000
    copyright            : (C) 2000 by 
    email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef VECTOR3D_H
#define VECTOR3D_H

class ostream;
class istream;

class Vector3D {

   friend Vector3D operator+(const Vector3D& larg, const Vector3D& rarg);
   friend Vector3D operator-(const Vector3D& larg, const Vector3D& rarg);
   friend Vector3D operator*(const Vector3D& larg, const Vector3D& rarg);
   friend float    smul(const Vector3D& larg, const Vector3D& rarg);
   friend bool     operator==(const Vector3D& larg, const Vector3D& rarg);
   friend ostream& operator<<(ostream& s, const Vector3D& v);
   friend istream& operator>>(istream& s, Vector3D& v);

public:
   static const Vector3D NULVECT;
	
   Vector3D(float x, float y, float z);
	~Vector3D(){};
private:
	float _x;
   float _y;
   float _z;
};

Vector3D operator+(const Vector3D& larg, const Vector3D& rarg);
Vector3D operator-(const Vector3D& larg, const Vector3D& rarg);
Vector3D operator*(const Vector3D& larg, const Vector3D& rarg);
float    smul(const Vector3D& larg, const Vector3D& rarg);
ostream& operator<<(ostream& s, const Vector3D& v);
istream& operator>>(istream& s, Vector3D& v);


bool     operator==(const Vector3D& larg, const Vector3D& rarg);


#endif
