/***************************************************************************
                          vector3d.cpp  -  description
                             -------------------
    begin                : Wed Nov 22 2000
    copyright            : (C) 2000 by 
    email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "vector3d.h"
#include <iostream>

const Vector3D Vector3D::NULVECT(0,0,0);

Vector3D::Vector3D(float x, float y, float z):
_x(x), _y(y), _z(z)
{}


Vector3D operator+(const Vector3D& larg, const Vector3D& rarg)
{
   return Vector3D(larg._x+rarg._x,larg._y+rarg._y,larg._z+rarg._z);
}
Vector3D operator-(const Vector3D& larg, const Vector3D& rarg)
{
   return Vector3D(larg._x-rarg._x,larg._y-rarg._y,larg._z-rarg._z);
}
Vector3D operator*(const Vector3D& larg, const Vector3D& rarg)
{
   return Vector3D(larg._y*rarg._z-larg._z*rarg._y,
                   larg._z*rarg._x-larg._x*rarg._z,
                   larg._x*rarg._y-larg._y*rarg._x);
}

float smul(const Vector3D& larg, const Vector3D& rarg)
{
   return larg._x*rarg._x+larg._y*rarg._y+larg._z*rarg._z;
}

bool operator==(const Vector3D& larg, const Vector3D& rarg)
{
   return larg._x == rarg._x &&
          larg._y == rarg._y &&
          larg._z == rarg._z;
}


ostream& operator<<(ostream& s, const Vector3D& v)
{
   s << '[' << v._x << ',' << v._y << ',' << v._z << ']';
   return s;
}

istream& operator>>(istream& s, Vector3D& v)
{
   char dummy;
   s >> dummy >> v._x >> dummy >> v._y >> dummy >> v._z >> dummy;
   return s;
}


