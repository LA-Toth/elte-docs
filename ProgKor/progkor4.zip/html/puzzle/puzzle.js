<!--

var startClock="megne";
var megyAjatek="nem";
var stopSec=0;
var okCounter=0;
var helpCounter=0;
var helpShow="no";
var dragObj=new Array(); 
var dx, dy;
var startX, startY;
window.captureEvents(Event.MOUSEDOWN | Event.MOUSEUP);
window.releaseEvents(Event.DRAGDROP);
window.onmousedown=startDrag;
window.onmouseup=endDrag;
window.onmousemove=moveIt;

function startDrag(e)
{
  if (megyAjatek == "igen")
    {
      currentObj=whichObj(e);
      startTime();
      if (currentObj != null)
        if (e.which != 1)
          igazit();
         else
          {
            startX=e.pageX;
            startY=e.pageY;
            window.releaseEvents(Event.DRAGDROP);
            window.captureEvents(Event.MOUSEMOVE);
          }
    }
}

function startTime()
{
  if (currentObj != null && startClock == "megne")
    {
      startClock="yes";
      startDate=new Date();
      document.layers["l_clock"].visibility="show";
      showClock();
    }
}

function igazit()
{
  if (currentObj != null)
    {
      currX=dragObj[currentObj].left;
      currY=dragObj[currentObj].top;
      diffX=(currX+10)%160;
      diffY=(currY+10)%120;
      if ((Math.abs(diffX) < 21) && (Math.abs(diffY) < 21))
      {
        dragObj[currentObj].left=currX+10-diffX;
        dragObj[currentObj].top=currY+10-diffY;
      }
    }
}

function moveIt(e)
{
  if (megyAjatek == "igen" && currentObj != null)
    {
      dragObj[currentObj].left=e.pageX - dx;
      dragObj[currentObj].top=e.pageY - dy;
    }
}

function endDrag(e)
{
  if (megyAjatek == "igen" && currentObj != null)
    {
      if (Math.abs(startX-e.pageX) < 11 &&
          Math.abs(startY-e.pageY) < 11)
        igazit();
      currentObj=null;
      window.releaseEvents(Event.MOUSEMOVE);
      setStat();
    }
}

function setStat()
{
  okCounter=0;
  for (var i=1; i<5; i++)
    for (var j=1; j<5; j++)
      {
        lX=document.layers["l_"+i+j].left;
        lY=document.layers["l_"+i+j].top;
        if (lX == 160*(j-1) && lY == 120*(i-1))
          okCounter++;
      }
  if (okCounter == 16)
    {
      document.layers["l_stat"].visibility="show";
      document.layers["l_clock"].visibility="hide";
      startClock="vege";
    }
  showStat();
}

function init()
{
  setTimeout("kesleltet()",3000);
  document.layers["l_clock"].visibility="show";
  sec=3; szamlal();
  return true;
}

function szamlal()
{
  if (sec > 0)
    {
      document.layers["l_clock"].document.open();
      ckiir("<FONT COLOR=yellow><B>");
      ckiir(sec); sec--;
      document.layers["l_clock"].document.close();
      setTimeout("szamlal()",1000);
    }
   else
    {
      document.layers["l_clock"].visibility="hide";
      document.layers["l_stat"].visibility="hide";
      megyAjatek="igen";
    }
}

function kesleltet()
{
  for (var i=1; i<5; i++)
    for (var j=1; j<5; j++)
      {
        objIndex=4*(i-1)+j-1;
        dragObj[objIndex]=document.layers["l_"+i+j];
        posShowKiskep("l_"+i+j);
      }
  document.layers["nagykep"].visibility="hide";
  document.layers["l_gomb"].visibility="show";
}

function whichObj(e)
{
  var hit=null;
  for (var i=0; i < dragObj.length; i++) {
    if ((dragObj[i].left < e.pageX) &&
        (dragObj[i].left + dragObj[i].clip.width > e.pageX) &&
        (dragObj[i].top < e.pageY) && 
        (dragObj[i].top + dragObj[i].clip.height > e.pageY))
      if ((hit==null) || (dragObj[i].zIndex > dragObj[hit].zIndex))
        hit=i;
  }
  if (hit != null)
    {
      dx=e.pageX-dragObj[hit].left;
      dy=e.pageY-dragObj[hit].top;
    }
  return hit;
}

function posShowKiskep(layer)
{
  document.layers[layer].left=Math.round(600*Math.random());
  document.layers[layer].top=Math.round(450*Math.random());
  document.layers[layer].zIndex=10+Math.round(200*Math.random());
  document.layers[layer].visibility="show";
  return true;
}

function showHide_nagykep()
{
  if (document.layers["nagykep"].visibility == "hide")
    {
      if (okCounter != 16)
        {
          if (document.layers["l_help"].visibility == "show")
            hideHelpShowKiskep();
          document.layers["nagykep"].visibility="show";
          if (startClock != "vege")
          {
            helpCounter++;
            showStat();
          }
        }
    }
   else
    document.layers["nagykep"].visibility="hide";
  return true;
}

function showHide_l_stat()
{
  if (document.layers["l_stat"].visibility == "hide")
    {
      document.layers["l_stat"].visibility="show";
      showStat();
    }
   else
    document.layers["l_stat"].visibility="hide";
  return true;
}

function showHide_l_help()
{
  if (document.layers["l_help"].visibility == "hide")
    showHelpHideKiskep();
   else
    hideHelpShowKiskep();
  return true;
}
function showHelpHideKiskep()
{
  megyAjatek="nem";
  if (startClock == "yes")
    {
      stopDate=new Date();
      startClock="stop";
    }
  for (var i=1; i<5; i++)
    for (var j=1; j<5; j++)
      document.layers["l_"+i+j].visibility="hide";
  document.layers["l_help"].visibility="show";
  return true;
}
function hideHelpShowKiskep()
{
  document.layers["l_help"].visibility="hide";
  for (var i=1; i<5; i++)
    for (var j=1; j<5; j++)
      document.layers["l_"+i+j].visibility="show";
  megyAjatek="igen";
  if (startClock == "stop")
    {
      startClock="yes";
      actDate=new Date();
      stopSec=stopSec+Math.round((actDate-stopDate)/1000);
      showClock();
    }
  return true;
}

function showClock()
{
  if (startClock == "yes")
    {
      actDate=new Date();
      masodperc=Math.round((actDate-startDate)/1000)-stopSec;
      min=Math.floor(masodperc/60);
      sec=masodperc%60;
      document.layers["l_clock"].document.open();
      ckiir("<FONT COLOR=yellow>");
      ckiir(min+"'"+sec+'"');
      document.layers["l_clock"].document.close();
      setTimeout("showClock()",1000);
    }
}
function ckiir(mit)
{
  document.layers["l_clock"].document.writeln(mit);
}

function showStat()
{
  if (document.layers["l_stat"].visibility == "show" || startClock == "vege")
    {
      document.layers["l_stat"].document.open();
      if (startClock != "vege" && helpCounter == 0)
        skiir("<SPACER TYPE=VERTICAL SIZE=24>");
       else
      if (startClock != "vege" || helpCounter == 0)
        skiir("<SPACER TYPE=VERTICAL SIZE=16>");
      skiir("<DIV ALIGN=right>");
      skiir("<FONT COLOR=yellow SIZE=4><B>");
      skiir(okCounter);
      skiir("<FONT COLOR=white SIZE=4>");
      skiir(" k�p van a hely�n");
      if (helpCounter != 0)
        skiir("<BR>"+helpCounter+"x k�rte a nagy k�pet");
      if (startClock == "vege")
        {
          skiir("<BR>A felhaszn�lt id�:");
          skiir("<FONT COLOR=yellow SIZE=4>");
          skiir(min+"'"+sec+'"');
        }
      document.layers["l_stat"].document.close();
    }
}
function skiir(mit)
{
  document.layers["l_stat"].document.writeln(mit);
}

// -->
