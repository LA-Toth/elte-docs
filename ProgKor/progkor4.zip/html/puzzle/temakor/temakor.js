<!-- hide

function kisKep(melyik,szoveg)
{
  parent.BALKOZEP.document.open();
  kiir("<HTML>");
  kiir("<HEAD><TITLE></TITLE>");
  kiir("</HEAD>");
  kiir("<BASE TARGET=_blank>");
  kiir("<BODY BACKGROUND=../hatter1.gif");
  kiir("      link='white'");
  kiir("      vlink='yellow'");
  kiir("      alink='yellow'");
  kiir("      TEXT=white>");
  kiir("<CENTER>");
  kiir("  <A HREF=''");
  kiir("     onClick=\"window.open('../puzzles/"+melyik+"/index.htm','index','width=790,height=590,screenX=0,screenY=0,toolbar=no,location=no,directoryes=no,menubar=no,resizable=yes,scrollbars=no,status=no,titlebar=yes');return false;\">");
  kiir("     <IMG SRC=../puzzles/"+melyik+"/kis_kep.jpg ALT='"+szoveg+"'></A>");
  kiir("<B>"+szoveg+"</B>");
  kiir("</BODY></HTML>");
  parent.BALKOZEP.document.close();
  return true;
}
function kiir(mit)
{
  parent.BALKOZEP.document.writeln(mit);
}

// -->
