<!--

function kepvalt(kepnev,kepfajlnev,layer)
{
  if (arguments.length == 3)
    document.layers[layer].document.images[kepnev].src=kepfajlnev;
   else
    document.images[kepnev].src=kepfajlnev;
  return true;
}

// -->
