<!-- hide
function showLayerT(wlayer,wleft,wtop)
{
  if (document.layers["l_OverOut"].visibility == "hide")
    {
      document.layers["l_OverOut"].left=wleft;
      document.layers["l_OverOut"].top=wtop;
      document.layers["l_OverOut"].load("../kejpg/"+wlayer+".jpg",screen.availWidth-wleft-90);
      document.layers["l_OverOut"].visibility= "show";
    }
  return true;
}
function hideLayerT()
{
  if (document.layers["l_OverOut"].visibility == "show")
    document.layers["l_OverOut"].visibility= "hide";
  return true;
}
// -->
