//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ActnList.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <Menus.hpp>
#include "users_basic.hpp"
#include "users_cs.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TActionList *ActionList1;
        TAction *ChangeUserPassword;
        TAction *UserAdministration;
        TAction *Login;
        TMainMenu *MainMenu1;
        TMenuItem *Customer1;
        TMenuItem *NewCustomer1;
        TMenuItem *ViewPrivateData1;
        TMenuItem *N2;
        TMenuItem *ViewOrders1;
        TMenuItem *Users1;
        TMenuItem *UserAdministration1;
        TMenuItem *ChangeUserPassword1;
        TMenuItem *N1;
        TMenuItem *Login1;
        TUsersCS *UsersCS1;
        TUsersCSReg *UsersCSReg1;
        TDatabase *dbUsers;
        void __fastcall ChangeUserPasswordExecute(TObject *Sender);
        void __fastcall UserAdministrationExecute(TObject *Sender);
        void __fastcall LoginExecute(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ViewOrders1Click(TObject *Sender);
        void __fastcall dbUsersBeforeConnect(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
