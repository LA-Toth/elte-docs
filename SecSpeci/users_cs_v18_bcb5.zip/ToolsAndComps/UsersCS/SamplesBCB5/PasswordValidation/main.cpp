//---------------------------------------------------------------------------

#include <vcl.h>
#include <string.h>
#pragma hdrstop

#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "users_basic"
#pragma link "users_cs"
#pragma link "users_basic"
#pragma link "users_cs"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UserAdministration1Click(TObject *Sender)
{
   UsersCS1->UsersAdm();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ChangeUserPassword1Click(TObject *Sender)
{
   UsersCS1->ChangeUserPassword();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Login1Click(TObject *Sender)
{
   if (!UsersCS1->Login())
   {
     Application->Terminate();
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  ShowMessage("User Name: master\nPassword: master");
  //Login->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UsersCS1ValidatePassword(AnsiString Password,
      bool &Accept)
{
  int i;
  // the minimum size for the password is already validated by the property MinPwdSize
  //  we will verify the demand of at least a number
  Accept=false;
  for (i=1;i<=Password.Length();i++)
  {
    if (!isalpha(Password[i]))
    // accepts password and breaks the loop
    {
      Accept=true;
      break;
    }
  }
  if (!Accept)
    ShowMessage("Password must contain at least one numeric character.");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::dbUsersBeforeConnect(TObject *Sender)
{
   dbUsers->Params->Values["PATH"]=ExtractFilePath(Application->ExeName)+"..\\Data";
}
//---------------------------------------------------------------------------

