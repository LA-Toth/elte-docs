//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("CustomLogin.res");
USEFORM("main_cb5.cpp", Form1);
USEFORM("custom_login.cpp", frmCustomLogin);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
