//---------------------------------------------------------------------------

#ifndef custom_loginH
#define custom_loginH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TfrmCustomLogin : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TPanel *Panel3;
        TLabel *lblUserName;
        TLabel *lblPassword;
        TImage *Image1;
        TEdit *Usuario;
        TButton *OKBtn;
        TButton *CancelBtn;
        TEdit *Senha;
        TStaticText *StaticText1;
private:	// User declarations
public:		// User declarations
        __fastcall TfrmCustomLogin(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmCustomLogin *frmCustomLogin;
//---------------------------------------------------------------------------
#endif
