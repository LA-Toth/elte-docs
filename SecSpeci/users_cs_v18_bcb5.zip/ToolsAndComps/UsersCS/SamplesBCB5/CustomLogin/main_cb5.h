//---------------------------------------------------------------------------

#ifndef main_cb5H
#define main_cb5H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include "users_basic.hpp"
#include "users_cs.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TButton *Button1;
        TUsersCS *UsersCS1;
        TUsersCSReg *UsersCSReg1;
        TDatabase *dbUsers;
        void __fastcall UsersCS1Login(AnsiString &UserName,
          AnsiString &Password, TModalResult &ModalResult);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall dbUsersBeforeConnect(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
