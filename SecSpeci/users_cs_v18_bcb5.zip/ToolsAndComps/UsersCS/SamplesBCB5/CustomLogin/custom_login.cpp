//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "custom_login.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmCustomLogin *frmCustomLogin;
//---------------------------------------------------------------------------
__fastcall TfrmCustomLogin::TfrmCustomLogin(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

