//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main_cb5.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "users_basic"
#pragma link "users_cs"
#pragma link "users_basic"
#pragma link "users_cs"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ShowUserNameExecute(TObject *Sender)
{
  ShowMessage("User Name is "+UsersCS1->ActualUser->UserName);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ShowUserPasswordExecute(TObject *Sender)
{
  ShowMessage("User Password is "+UsersCS1->ActualUser->Password);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ChangeUserPasswordExecute(TObject *Sender)
{
  UsersCS1->ChangeUserPassword();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UserAdministrationExecute(TObject *Sender)
{
  UsersCS1->UsersAdm();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::LoginExecute(TObject *Sender)
{
  if (!UsersCS1->Login())
    Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  ShowMessage("User Name: master \nPassword: master");
  Login->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::dbUsersBeforeConnect(TObject *Sender)
{
   dbUsers->Params->Values["PATH"]=ExtractFilePath(Application->ExeName)+"..\\Data";
}
//---------------------------------------------------------------------------

