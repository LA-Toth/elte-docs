//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "dtm_Sample.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "users_basic"
#pragma link "users_cs"
#pragma resource "*.dfm"
TSampleData *SampleData;

String OldCompanyName="";

//---------------------------------------------------------------------------
__fastcall TSampleData::TSampleData(TComponent* Owner)
        : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSampleData::CompaniesBeforePost(TDataSet *DataSet)
{
  if (CompaniesCompany_Name->Value!=OldCompanyName)
  {
    UsersCSReg1->Audit(CompaniesCompany_Name->Name,"Name Change","Old Name: "+OldCompanyName+"\nNew Name: "+CompaniesCompany_Name->Value);
  }
}
//---------------------------------------------------------------------------
void __fastcall TSampleData::DataModuleCreate(TObject *Sender)
{
  Companies->Open();        
}
//---------------------------------------------------------------------------
void __fastcall TSampleData::CompaniesAfterPost(TDataSet *DataSet)
{
  Companies->ApplyUpdates();
  Companies->CommitUpdates();
}
//---------------------------------------------------------------------------
void __fastcall TSampleData::CompaniesBeforeEdit(TDataSet *DataSet)
{
  OldCompanyName=CompaniesCompany_Name->Value;
}
//---------------------------------------------------------------------------

