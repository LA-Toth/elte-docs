//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("ProtectingFields.res");
USEFORM("main.cpp", Form1);
USEFORM("dtm_Sample.cpp", SampleData); /* TDataModule: File Type */
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TSampleData), &SampleData);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
