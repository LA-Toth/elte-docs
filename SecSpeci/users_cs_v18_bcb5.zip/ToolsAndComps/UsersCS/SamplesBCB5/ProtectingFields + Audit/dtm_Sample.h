//---------------------------------------------------------------------------

#ifndef dtm_SampleH
#define dtm_SampleH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "users_basic.hpp"
#include "users_cs.hpp"
#include <Db.hpp>
#include <DBTables.hpp>
//---------------------------------------------------------------------------
class TSampleData : public TDataModule
{
__published:	// IDE-managed Components
        TQuery *Companies;
        TStringField *CompaniesCompany_Name;
        TIntegerField *CompaniesCompany_Id;
        TStringField *CompaniesCompany_Address;
        TStringField *CompaniesCompany_Phone;
        TStringField *CompaniesCompany_FAX;
        TStringField *CompaniesCompanyUserName;
        TDataSource *dtsCompanies;
        TUsersCSReg *UsersCSReg1;
        void __fastcall CompaniesBeforePost(TDataSet *DataSet);
        void __fastcall DataModuleCreate(TObject *Sender);
        void __fastcall CompaniesAfterPost(TDataSet *DataSet);
        void __fastcall CompaniesBeforeEdit(TDataSet *DataSet);
private:	// User declarations
public:		// User declarations
        __fastcall TSampleData(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSampleData *SampleData;
//---------------------------------------------------------------------------
#endif
