//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "dtm_Sample.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "users_basic"
#pragma link "users_cs"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ChangeUserPasswordExecute(TObject *Sender)
{
  UsersCS1->ChangeUserPassword();        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UserAdministrationExecute(TObject *Sender)
{
  UsersCS1->UsersAdm();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::LoginExecute(TObject *Sender)
{
  if (!UsersCS1->Login())
  {
    Application->Terminate();
  }
  Panel3->Caption="User: " + UsersCS1->ActualUser->UserName+" ["+UsersCS1->ActualUser->RealName+"]";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  ShowMessage("User Name: master\nPassword: master");
  Login->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::dbUsersBeforeConnect(TObject *Sender)
{
   dbUsers->Params->Values["PATH"]=ExtractFilePath(Application->ExeName)+"..\\Data";
}
//---------------------------------------------------------------------------

