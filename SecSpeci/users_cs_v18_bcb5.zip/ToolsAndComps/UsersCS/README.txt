TUsersCS Security Component v1.8
Tools&Comps - Security Components for Delphi and C++ Builder
Web Site: http://www.toolsandcomps.com
  e-mail: info@toolsandcomps.com

  Addres: Rua do Beijo, 9 - Novo M�xico
          Vila Velha - ES - Brasil
     CEP: 29104-080-020
   Phone: 55 27 33891138/55 27 99602760

Last Update: July 21, 2001

CONTENTS
--------

� Installation
� Sample Applications 
� Changing the idiom of the component
� What's new
� Updating the database
� Important information for MS-Access users

Installation
------------

In order to install this version of TUsersCS, please remove tre previous versions you have installed on your computer. Be sure to verify if there is any old files in the Projecst\Bpl directory of your Delphi Installation.

Be sure to change the Library paths settings of your Delphi environment to the correct directories. Also include in the Library path settings, the path for the unit crypto.pas, which is in the directory \ToolsAncComps\UsersCS\Crypto. 

Sample Applications
--------------------

The sample applications uses a set of Paradox tables and does not needs extra configurations in order tu run. The Paradox tables can be found in ToolsAndComps\UsersCS\Samples\Data.

If you are going to test the SAC.EXE (Security Administration Central) application, you must run all the other applications as the master user first in order to register them in the security database.

Changing the idiom of the component  
-----------------------------------  
  
In case the language presented by the component it is not the language of your choice, go to the directory UsersCs\Resources and copy the files that are inside of the directory of the language of your choice to the directory where component DCU's are stored. After copying the files, recompile your application.

What's new 
----------
Version 1.8(July 21, 2001)

� Changes when securing a Dataset: Now when you apply security restrictions to a Dataset which its Fields where not selected for protection, TUsersCS automaticaly copies the Dataset configuration to the Fields 
� Fixed BUG: Registering components at run-time was not working properly.
� New event OnApplySecurity: New TUsersCSReg event, which is triggered for each secured Object. This event has as parameters the Object which will be secured by the component as also the security information of the Object regarding the current user. With this event the developer can perform extra configuration in the Object beeing secured and also inform TUsesCSReg if the component must proceed or not with the security configuration to the Object.
� Now the component also suports TCustomActions

Version 1.7 (July 01, 2001) 
� Fixed BUG: When applying the security configuration into a TPageControl with several TTabSheets, the component was making the last TTabSheet as the Active TabSheet.
� Fixed BUG: In the Component Registration Form, some unnecessary components were beeing showed, like TDatasources.
� Fixed BUG: In the Component Registration Form, now all the controls inside a TCoolbar are beeing showed
� Fixed BUG: In the Component Registration Form, some components were beeing showed twice

Version 1.7 (May 30, 2001) 

� Fixed BUG: New profiles where showed only after re-starting the User Administration Module
� Fixed BUG: The component was not fixing the Login Trace information properly when a aplication have abnormal termination and was load again. This error just was happening when you were using Paradox files with short names (property FileNames83DOS as True)
� New events: BeforeLogins, WhileDoLogin and AfterLogin (See the samples)

Version 1.7 (May 15, 2001) 
� Was Added new propertye MaxCurrentUsers(Integer). The property MaxCurrentUsers indicates the maximum number of users that can be running the application at the same time. 
� Was Added new property HaltOnReachMaxCurrentUsers(Boolean). The property HaltOnReachMaxCurrentUsers indicates if the component will terminate the application if the maximum number of current users is reached
� Was Added new function GetNumberOfCurrentUsers. This function returns the number of users that are using the application when the function is called.

Version 1.7 (April 19, 2001) 
 
� Support to Developer Express components (Express Bars, Express Quantum Grid and Express Quantum TreeList).   
� We did a substantial change in the algorithm for exhibition of components in the registration form and now almost all visual components will be showed in the Component Registration Form.  
� New method and an event for the registration of components in run time. 
� The standard cryptography algorithm of the component was changed. There was a bug in the old algorithm, that didn't allow decrypt texts with letters duplicated in sequence correctly. Old users need to execute the program in order to change the password�s cryptography.  
� We increased the size of the password�s field for 60 characters. That allows the use of other cryptography algorithms. Old users need to execute the program in order to update the security database.
� We also increased the size of the of the user's name field for 30 characters. Old users need to execute the program in order to update the security database.
� New method that allows to verify the status of a component in relation to an user that is not logged in the application. 
� New form for visualization of the registered forms.  
� Corrected referring BUGs to columns that don't accept null values and to names of ambiguous columns in some databases (MS-SQL Server and Oracle).  
� New method that shows the list of all the applications registered in the security database. Now it is possible to have an only application to manage the security administration. 
� Corrected  a installation problem of the packages.  
� New property booleand MSAccess, that indicates to the component if the security database is stored in a MS-Access database.  
� Due to some requisitions, we made available again TUsersCS for Delphi 3.  
� Included new examples.

Version 1.6 and 1.5.5

� Was Added support to Actions
� Event for pasword validation 
� Customization of the user�s cadaster screen
� Access restriction to records (Needs programming)
� Application Time Out 
� Several Reports
	a) User Listing
	b) Profile Listing
	c) User Permissions Listing
	d) Profile Permissions Listing
	e) Listing of the Login Activities of a User 
	f) Listing of the Component Utilization by the Users 
	g) Listing of the User ACtivities 
� Do not allows multiple logins for a same user name 
� Disable a user after N days without using the application
� Disable a user after N attemps of login with no success
� New field ADDITIONAL_INFO to be used to keep extra user information, making possible to restrict records from some users
� Better performance
� More flexibility when configuring the access of the users: now is possible to mix among the options Visible, Invisible and Visible but disabled for each component.

Updating the database
---------------------
If you are a TUsersCS v1.5 user, you need to run the setup program in order to update your database.

Important information for MS-Access users
-----------------------------------------
The TUsersCS component has a flag that must be modified in order to use a MS-Access file as the database for the security tables. Just select the component in the Object Inspector and set the value of the property MSAccess to true.

Thank you for choose TUsersCS

If you find any bug in this component or you can't test it for any reason, please, report us the error so we can fix it.

->>> Read teh user manual carefully for better undestanding the new features
->>> Take a look in the sample applications that are located in the directory UsersCS\Samples for a sample of utilization of the component features.

