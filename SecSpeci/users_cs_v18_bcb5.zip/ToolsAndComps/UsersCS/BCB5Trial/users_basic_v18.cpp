//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("users_basic_v18.res");
USEPACKAGE("vcl50.bpi");
USEFORMNS("chng_pwd.pas", Chng_pwd, frmChangePwd);
USEUNIT("crypto.pas");
USEFORMNS("dlgsearch.pas", Dlgsearch, fDlgSearch);
USEFORMNS("dtm_login.pas", Dtm_login, UserLogin); /* TDataModule: File Type */
USEFORMNS("dtm_users.pas", Dtm_users, Users); /* TDataModule: File Type */
USEFORMNS("login.pas", Login, frmLogin);
USEFORMNS("new_profile.pas", New_profile, frmNewProfile);
USEFORMNS("new_user.pas", New_user, frmNewUser);
USEFORMNS("rpt_comp_utilization.pas", Rpt_comp_utilization, rpt_CompUtilization);
USEFORMNS("rpt_permissions.pas", Rpt_permissions, rpt_UPPermissions);
USEFORMNS("rpt_prof_list.pas", Rpt_prof_list, rpt_ProfList);
USEFORMNS("rpt_user_activity.pas", Rpt_user_activity, rpt_UserActivity);
USEFORMNS("rpt_user_list.pas", Rpt_user_list, rpt_UserList);
USEFORMNS("rpt_user_login_activity.pas", Rpt_user_login_activity, rpt_UserLoginActivity);
USEFORMNS("user_adm.pas", User_adm, UserAdministration);
USEUNIT("users_basic.pas");
USEUNIT("users_res.pas");
USEPACKAGE("VCLX50.bpi");
USEPACKAGE("VCLDB50.bpi");
USEPACKAGE("VCLBDE50.bpi");
USEPACKAGE("QRPT50.bpi");
USEFORMNS("users_sac.pas", Users_sac, SecurityAdministrationCentral);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
