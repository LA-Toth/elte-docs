// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rpt_user_list.pas' rev: 5.00

#ifndef rpt_user_listHPP
#define rpt_user_listHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <QuickRpt.hpp>	// Pascal unit
#include <Qrctrls.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rpt_user_list
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Trpt_UserList;
class PASCALIMPLEMENTATION Trpt_UserList : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Quickrpt::TQuickRep* QuickRep;
	Quickrpt::TQRBand* DetailBand1;
	Quickrpt::TQRBand* PageFooterBand1;
	Quickrpt::TQRBand* TitleBand1;
	Qrctrls::TQRSysData* QRSysData1;
	Qrctrls::TQRDBText* QRDBText1;
	Qrctrls::TQRDBText* QRDBText2;
	Qrctrls::TQRDBText* QRDBText3;
	Qrctrls::TQRDBText* QRDBText4;
	Qrctrls::TQRDBText* QRDBText5;
	Qrctrls::TQRDBText* QRDBText6;
	Qrctrls::TQRDBText* QRDBText7;
	Qrctrls::TQRDBText* QRDBText8;
	Qrctrls::TQRSysData* qrsData;
	Qrctrls::TQRLabel* qrlProfile;
	Qrctrls::TQRLabel* qrlUserName;
	Qrctrls::TQRLabel* qrlRealName;
	Qrctrls::TQRLabel* qrlAuditMode;
	Qrctrls::TQRLabel* qrlActive;
	Qrctrls::TQRLabel* qrlExpires;
	Qrctrls::TQRLabel* qrlExpirationDate;
	Qrctrls::TQRLabel* qrlAdmin;
	void __fastcall QRDBText4Print(System::TObject* sender, AnsiString &Value);
	void __fastcall QRDBText7Print(System::TObject* sender, AnsiString &Value);
	void __fastcall qrlUserNamePrint(System::TObject* sender, AnsiString &Value);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual Trpt_UserList(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual Trpt_UserList(Classes::TComponent* AOwner, int 
		Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~Trpt_UserList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall Trpt_UserList(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Trpt_UserList* rpt_UserList;

}	/* namespace Rpt_user_list */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Rpt_user_list;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rpt_user_list
