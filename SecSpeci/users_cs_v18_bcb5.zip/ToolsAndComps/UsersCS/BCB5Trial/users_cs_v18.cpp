//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("users_cs_v18.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("users_cs.pas");
USERES("users_cs.dcr");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("VCLBDE50.bpi");
USEPACKAGE("users_basic_v18.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
