// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rpt_comp_utilization.pas' rev: 5.00

#ifndef rpt_comp_utilizationHPP
#define rpt_comp_utilizationHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <QuickRpt.hpp>	// Pascal unit
#include <Qrctrls.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rpt_comp_utilization
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Trpt_CompUtilization;
class PASCALIMPLEMENTATION Trpt_CompUtilization : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Quickrpt::TQuickRep* QuickRep;
	Quickrpt::TQRBand* PageFooterBand1;
	Qrctrls::TQRSysData* qrsData;
	Quickrpt::TQRBand* TitleBand1;
	Qrctrls::TQRSysData* QRSysData1;
	Qrctrls::TQRLabel* qrlItem;
	Qrctrls::TQRLabel* qrlPeriod;
	Quickrpt::TQRBand* ColumnHeaderBand1;
	Qrctrls::TQRLabel* qrlUserName;
	Qrctrls::TQRLabel* qrlDate;
	Qrctrls::TQRLabel* qrlComputer;
	Quickrpt::TQRBand* DetailBand1;
	Qrctrls::TQRDBText* QRDBText1;
	Qrctrls::TQRDBText* QRDBText2;
	Qrctrls::TQRDBText* QRDBText3;
	Qrctrls::TQRLabel* qrlModule;
	Qrctrls::TQRLabel* qrlAdditionalInfo;
	Qrctrls::TQRMemo* qrmAdditionalInfo;
	void __fastcall DetailBand1BeforePrint(Quickrpt::TQRCustomBand* Sender, bool &PrintBand);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual Trpt_CompUtilization(Classes::TComponent* AOwner
		) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual Trpt_CompUtilization(Classes::TComponent* AOwner
		, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~Trpt_CompUtilization(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall Trpt_CompUtilization(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Trpt_CompUtilization* rpt_CompUtilization;

}	/* namespace Rpt_comp_utilization */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Rpt_comp_utilization;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rpt_comp_utilization
