//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("p_editors_pkg.res");
USEPACKAGE("vcl50.bpi");
USEFORMNS("reg_form_list.pas", Reg_form_list, frmRegForms);
USEFORMNS("reg_form.pas", Reg_form, fRegForm);
USEUNIT("p_editors.pas");
USEPACKAGE("VCLX50.bpi");
USEPACKAGE("VCLDB50.bpi");
USEPACKAGE("VCLBDE50.bpi");
USEPACKAGE("users_basic_v18.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
