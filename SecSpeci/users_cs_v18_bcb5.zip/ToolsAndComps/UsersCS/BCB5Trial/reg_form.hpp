// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'reg_form.pas' rev: 5.00

#ifndef reg_formHPP
#define reg_formHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <DBGrids.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <ActnList.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <CheckLst.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Reg_form
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfRegForm;
class PASCALIMPLEMENTATION TfRegForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Comctrls::TPageControl* pc;
	Comctrls::TTabSheet* tsAvailableComponents;
	Comctrls::TTreeView* tvComponents;
	Controls::TImageList* ImageList1;
	Extctrls::TPanel* Panel2;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TLabel* lblCompName;
	Stdctrls::TEdit* edtCompName;
	Stdctrls::TEdit* edtCompClass;
	Stdctrls::TLabel* lblCompClass;
	Stdctrls::TEdit* edtCompCaption;
	Stdctrls::TLabel* lblCompCaption;
	Buttons::TBitBtn* btnClose;
	Stdctrls::TLabel* Label1;
	Menus::TPopupMenu* PopupMenu1;
	Menus::TMenuItem* CheckAllChildren;
	Menus::TMenuItem* Uncheckallchildren;
	void __fastcall FormActivate(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall tvComponentsMouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState 
		Shift, int X, int Y);
	void __fastcall tvComponentsChange(System::TObject* Sender, Comctrls::TTreeNode* Node);
	void __fastcall edtCompCaptionChange(System::TObject* Sender);
	void __fastcall FormDeactivate(System::TObject* Sender);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall CheckAllChildrenClick(System::TObject* Sender);
	
private:
	void __fastcall ProcessDBNavigator(Dbctrls::TDBNavigator* Comp, Comctrls::TTreeNode* ParentNode);
	void __fastcall ProcessDBGrid(Dbgrids::TDBGrid* Comp, Comctrls::TTreeNode* ParentNode);
	void __fastcall ProcessCoolBar(Comctrls::TCoolBar* Comp, Comctrls::TTreeNode* ParentNode);
	void __fastcall ProcessMenu(Menus::TMenu* Comp, Comctrls::TTreeNode* ParentNode);
	Comctrls::TTreeNode* __fastcall ProcessWinControl(Controls::TWinControl* Comp, Comctrls::TTreeNode* 
		ParentNode);
	Comctrls::TTreeNode* __fastcall ProcessControl(Controls::TControl* Comp, Comctrls::TTreeNode* ParentNode
		);
	void __fastcall ProcessDataset(Db::TDataSet* Dataset);
	void __fastcall ChildsTWinControl(Controls::TWinControl* Comp, Comctrls::TTreeNode* NodeParent);
	void __fastcall ProcessActionList(Actnlist::TActionList* Comp);
	void __fastcall ProcessSubClasses(System::TObject* Component, Comctrls::TTreeNode* ParentNode);
	void __fastcall ProcessComponent(Classes::TComponent* Comp, Comctrls::TTreeNode* ParentNode);
	bool __fastcall HasEssentialProperties(System::TObject* Comp);
	
public:
	Classes::TStringList* LocalCompList;
	Classes::TComponent* TheForm;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfRegForm(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfRegForm(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfRegForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfRegForm(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Reg_form */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Reg_form;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// reg_form
