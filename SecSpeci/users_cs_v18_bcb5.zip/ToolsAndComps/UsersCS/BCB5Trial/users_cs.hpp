// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'users_cs.pas' rev: 5.00

#ifndef users_csHPP
#define users_csHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <users_res.hpp>	// Pascal unit
#include <users_basic.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Users_cs
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUsersCS;
class PASCALIMPLEMENTATION TUsersCS : public Users_basic::TUsersBasic 
{
	typedef Users_basic::TUsersBasic inherited;
	
private:
	AnsiString FDatabaseName;
	Dbtables::TDatabase* FDatabase;
	bool FMSAccess;
	void __fastcall SetDatabaseName(const AnsiString Value);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	
public:
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual bool __fastcall InTransaction(void);
	virtual Classes::TComponent* __fastcall GetDatabase(void);
	
__published:
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property FileNames83DOS ;
	__property bool MSAccess = {read=FMSAccess, write=FMSAccess, nodefault};
public:
	#pragma option push -w-inl
	/* TUsersBasic.Create */ inline __fastcall virtual TUsersCS(Classes::TComponent* aOwner) : Users_basic::TUsersBasic(
		aOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TUsersBasic.Destroy */ inline __fastcall virtual ~TUsersCS(void) { }
	#pragma option pop
	
};


class DELPHICLASS TUsersCSReg;
class PASCALIMPLEMENTATION TUsersCSReg : public Users_basic::TUsersReg 
{
	typedef Users_basic::TUsersReg inherited;
	
public:
	#pragma option push -w-inl
	/* TUsersReg.Create */ inline __fastcall virtual TUsersCSReg(Classes::TComponent* Owner) : Users_basic::TUsersReg(
		Owner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TUsersReg.Destroy */ inline __fastcall virtual ~TUsersCSReg(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Users_cs */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Users_cs;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// users_cs
