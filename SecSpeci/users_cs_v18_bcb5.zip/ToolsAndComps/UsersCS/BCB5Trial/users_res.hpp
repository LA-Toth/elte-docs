// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'users_res.pas' rev: 5.00

#ifndef users_resHPP
#define users_resHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Users_res
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
static const Word strErrorDatabaseDir = 0x9c40;
static const Word strErrorOpenTables = 0x9c41;
static const Word strErrorPassword = 0x9c42;
static const Word strErrorUserName = 0x9c43;
static const Word strPasswordChanged = 0x9c44;
static const Word strErrorChangePassword = 0x9c45;
static const Word strErrorPwdsDiffers = 0x9c46;
static const Word strNewUserOk = 0x9c47;
static const Word strUserExists = 0x9c48;
static const Word strImpAddNewUser = 0x9c49;
static const Word strConfirmDeleteUser = 0x9c4a;
static const Word strUserDeleted = 0x9c4b;
static const Word strConfirmDeleteProfile = 0x9c4c;
static const Word strProfileDeleted = 0x9c4d;
static const Word strConfirm = 0x9c4e;
static const Word strChangePassword = 0x9c4f;
static const Word strCancelChangingPassword = 0x9c50;
static const Word strNewUserMainForm = 0x9c51;
static const Word strNewUser_lblUserName = 0x9c52;
static const Word strNewUser_lblPassword = 0x9c53;
static const Word strNewUser_lblRealName = 0x9c54;
static const Word strNewUser_OKBtn = 0x9c55;
static const Word strNewUser_CancelBtn = 0x9c56;
static const Word strNewUser_lblEXPIRATION_DATE = 0x9c57;
static const Word strNewUser_lblPROFILE = 0x9c58;
static const Word strNewUser_cbxUSER_EXPIRE = 0x9c59;
static const Word strNewUser_cbxUSER_ACTIVE = 0x9c5a;
static const Word strUsersAdministrationMainForm = 0x9c5b;
static const Word strUsersAdministration_tsUsers = 0x9c5c;
static const Word strUsersAdministration_tsUsersList = 0x9c5d;
static const Word strUsersAdministration_DBGridUsersColUSER_NAME = 0x9c5e;
static const Word strUsersAdministration_DBGridUsersColREAL_NAME = 0x9c5f;
static const Word strUsersAdministration_DBGridUsersColPROFILE = 0x9c60;
static const Word strUsersAdministration_DBGridUsersColUSER_ACTIVE = 0x9c61;
static const Word strUsersAdministration_tsUsersData = 0x9c62;
static const Word strUsersAdministration_lblLAST_PWD_CHANGE = 0x9c63;
static const Word strUsersAdministration_lblUserName = 0x9c64;
static const Word strUsersAdministration_lblRealName = 0x9c65;
static const Word strUsersAdministration_lblPassword = 0x9c66;
static const Word strUsersAdministration_lblEXPIRATION_DATE = 0x9c67;
static const Word strUsersAdministration_lblPROFILE = 0x9c68;
static const Word strUsersAdministration_cbxUSER_EXPIRE = 0x9c69;
static const Word strUsersAdministration_cbxUSER_ACTIVE = 0x9c6a;
static const Word strUsersAdministration_btnChangePassword = 0x9c6b;
static const Word strUsersAdministration_btnChangePasswordHint = 0x9c6c;
static const Word strUsersAdministration_PanelPwdHistory = 0x9c6d;
static const Word strUsersAdministration_DBGridPwdHistoryColPASSWORD = 0x9c6e;
static const Word strUsersAdministration_DBGridPwdHistoryColCHANGE_DATE = 0x9c6f;
static const Word strUsersAdministration_sbNewUser = 0x9c70;
static const Word strUsersAdministration_sbNewUserHint = 0x9c71;
static const Word strUsersAdministration_sbChangeUserData = 0x9c72;
static const Word strUsersAdministration_sbChangeUserDataHint = 0x9c73;
static const Word strUsersAdministration_sbUserAccess = 0x9c74;
static const Word strUsersAdministration_sbUserAccessHint = 0x9c75;
static const Word strUsersAdministration_sbDeleteUser = 0x9c76;
static const Word strUsersAdministration_sbDeleteUserHint = 0x9c77;
static const Word strUsersAdministration_tsProfiles = 0x9c78;
static const Word strUsersAdministration_tsProfilesList = 0x9c79;
static const Word strUsersAdministration_DBGridProfilesColPROF_DESCRIPTION = 0x9c7a;
static const Word strUsersAdministration_DBGridProfilesColMUST_CHANGE_PWD = 0x9c7b;
static const Word strUsersAdministration_DBGridProfilesColINTERVAL_CHANGE_PWD = 0x9c7c;
static const Word strUsersAdministration_DBGridProfilesColHIDE_DISABLE_MENU = 0x9c7d;
static const Word strInvisible = 0x9c7e;
static const Word strDisabled = 0x9c7f;
static const Word strUsersAdministration_tsProfilesData = 0x9c80;
static const Word strUsersAdministration_lblPROF_DESCRIPTION = 0x9c81;
static const Word strUsersAdministration_cbxMUST_CHANGE_PWD = 0x9c82;
static const Word strUsersAdministration_lblINTERVAL_CHANGE_PWD = 0x9c83;
static const Word strUsersAdministration_rgpHIDE_DISABLE_MENU = 0x9c84;
static const Word strUsersAdministration_sbNewProfile = 0x9c85;
static const Word strUsersAdministration_sbNewProfileHint = 0x9c86;
static const Word strUsersAdministration_sbProfileAccess = 0x9c87;
static const Word strUsersAdministration_sbProfileAccessHint = 0x9c88;
static const Word strUsersAdministration_sbChangeProfileData = 0x9c89;
static const Word strUsersAdministration_sbChangeProfileDataHint = 0x9c8a;
static const Word strUsersAdministration_sbDeleteProfile = 0x9c8b;
static const Word strUsersAdministration_sbDeleteProfileHint = 0x9c8c;
static const Word strUsersAdministration_tsPrograms = 0x9c8d;
static const Word strUsersAdministration_tsUsersProgs = 0x9c8e;
static const Word strUsersAdministration_DBGridUsersProgsColUSER_NAME = 0x9c8f;
static const Word strUsersAdministration_DBGridUsersProgsColPROFILE = 0x9c90;
static const Word strUsersAdministration_tsProfilesProgs = 0x9c91;
static const Word strUsersAdministration_DBGridProfilesProgsColPROF_DESCRIPTION = 0x9c92;
static const Word strUsersAdministration_sbApply = 0x9c93;
static const Word strUsersAdministration_sbApplyHintUser = 0x9c94;
static const Word strUsersAdministration_sbApplyHintProfile = 0x9c95;
static const Word strUsersAdministration_sbRestore = 0x9c96;
static const Word strUsersAdministration_sbRestoreHintUser = 0x9c97;
static const Word strUsersAdministration_sbRestoreHintProfile = 0x9c98;
static const Word strUsersAdministration_sbRestoreProfile = 0x9c99;
static const Word strUsersAdministration_sbRestoreProfileHint = 0x9c9a;
static const Word strUsersAdministration_sbUpdateUsers = 0x9c9b;
static const Word strUsersAdministration_sbUpdateUsersHint = 0x9c9c;
static const Word strUsersAdministration_PanelAboveProgs1 = 0x9c9d;
static const Word strUsersAdministration_PanelAboveProgs2 = 0x9c9e;
static const Word strUserAdministrationMsgChangeUserPwd = 0x9c9f;
static const Word strLoginMainForm = 0x9ca0;
static const Word strLogin_lblUserName = 0x9ca1;
static const Word strLogin_lblPassword = 0x9ca2;
static const Word strLogin_OKBtn = 0x9ca3;
static const Word strLogin_CancelBtn = 0x9ca4;
static const Word strChangePwdMainForm = 0x9ca5;
static const Word strChangePwd_lblOldPassword = 0x9ca6;
static const Word strChangePwd_lblNewPassword = 0x9ca7;
static const Word strChangePwd_lblPasswordAgain = 0x9ca8;
static const Word strChangePwd_OKBtn = 0x9ca9;
static const Word strChangePwd_CancelBtn = 0x9caa;
static const Word strNoProfile = 0x9cab;
static const Word strUserIsInactive = 0x9cac;
static const Word strPasswordExpired = 0x9cad;
static const Word strTryChangePasswordAgain = 0x9cae;
static const Word strPasswordUsedBefore = 0x9caf;
static const Word strNewProfileMainForm = 0x9cb0;
static const Word strNewProfile_lblPROF_DESCRIPTION = 0x9cb1;
static const Word strNewProfile_lblINTERVAL_CHANGE_PWD = 0x9cb2;
static const Word strNewProfile_OKBtn = 0x9cb3;
static const Word strNewProfile_CancelBtn = 0x9cb4;
static const Word strNewProfile_cbxMUST_CHANGE_PWD = 0x9cb5;
static const Word strNewProfile_rgpHIDE_DISABLE_MENU = 0x9cb6;
static const Word strNewProfile_rgpHIDE_MENU = 0x9cb7;
static const Word strNewProfile_rgpDISABLE_MENU = 0x9cb8;
static const Word strYes = 0x9cb9;
static const Word strNo = 0x9cba;
static const Word strINTERVAL_CHANGE_PWD_DisplayFormat = 0x9cbb;
static const Word strcbxAUDIT_MODE = 0x9cbc;
static const Word strUsersAdministration_tsAudit = 0x9cbd;
static const Word strUsersAdministration_tsLoginActivity = 0x9cbe;
static const Word strUsersAdministration_tsAudProgs = 0x9cbf;
static const Word strUsersAdministration_lblUser = 0x9cc0;
static const Word strUsersAdministration_lblProgram = 0x9cc1;
static const Word strUsersAdministration_gbxPeriodActivities = 0x9cc2;
static const Word strUsersAdministration_lblFrom = 0x9cc3;
static const Word strUsersAdministration_lblTo = 0x9cc4;
static const Word strUsersAdministration_COMPUTER_NAME = 0x9cc5;
static const Word strUsersAdministration_dbgLoginActivityColLOGIN_DATE_TIME = 0x9cc6;
static const Word strUsersAdministration_dbgLoginActivityColLOGOUT_DATE_TIME = 0x9cc7;
static const Word strConfirmDeleteAudit = 0x9cc8;
static const Word strstrDelete = 0x9cc9;
static const Word strUsersAdministration_cbxUSER_IS_ADMIN = 0x9cca;
static const Word strUsersAdministration_gbxFormList = 0x9ccb;
static const Word strUsersAdministration_DBGridAudUsersCOMP_CAPTION = 0x9ccc;
static const Word strUsersAdministration_DBGridAudUsersDATE_UTIL = 0x9ccd;
static const Word strUsersAdministration_tsCompUtilization = 0x9cce;
static const Word strUsersAdministration_tsUserActivity = 0x9ccf;
static const Word strUsersAdministration_gbxAddInfo1 = 0x9cd0;
static const Word strMustBeAdmin = 0x9cd1;
static const Word strMinPwdSizeMSG = 0x9cd2;
static const Word strPressF2MSG = 0x9cd3;
static const Word strUserSearch = 0x9cd4;
static const Word strProfileSearch = 0x9cd5;
static const Word strUsersAdministration_tabAdditionalInfo = 0x9cd6;
static const Word strUsersAdministration_pnlTopLegenda = 0x9cd7;
static const Word strUsersAdministratoin_pnlLegendaEnabled = 0x9cd8;
static const Word strUsersAdministration_pnlLegendaOnlyVisible = 0x9cd9;
static const Word strUsersAdministration_pnlLegendaInvisible = 0x9cda;
static const Word strUsersAdministration_btnLegenda = 0x9cdb;
static const Word strUserAdministration_menuAllEnabled = 0x9cdc;
static const Word strUserAdministration_menuAllDisabled = 0x9cdd;
static const Word strUserAdministration_menuAllInvisible = 0x9cde;
static const Word strUsersAdministration_ShowLengenda = 0x9cdf;
static const Word strErrorMultipleLoginsNoAllowed = 0x9ce0;
static const Word strCurrentUsers = 0x9ce1;
static const Word strbtnRefreshCurrenUsersList = 0x9ce2;
static const Word strsbPrintUserList = 0x9ce3;
static const Word strsbPrintUserAccess = 0x9ce4;
static const Word strtabAppConfig = 0x9ce5;
static const Word strlblTimeOut = 0x9ce6;
static const Word strlblMaxBadLogins = 0x9ce7;
static const Word strdbcbxDisableUser = 0x9ce8;
static const Word strlblInativeDays = 0x9ce9;
static const Word strlblMaxPwdHistory = 0x9cea;
static const Word strdbcbxMultipleLogins = 0x9ceb;
static const Word strqrModule = 0x9cec;
static const Word strLegend01 = 0x9ced;
static const Word strLegend02 = 0x9cee;
static const Word strLegend03 = 0x9cef;
static const Word strtvEnabled = 0x9cf0;
static const Word strtvDisabled = 0x9cf1;
static const Word strtvInvisible = 0x9cf2;
static const Word strrep_TitlePermissions = 0x9cf3;
static const Word strrep_TitleUserList = 0x9cf4;
static const Word strqrlExpires = 0x9cf5;
static const Word strqrlExpirationDate = 0x9cf6;
static const Word strqrlAdmin = 0x9cf7;
static const Word strrep_TitleProfList = 0x9cf8;
static const Word strrep_TitleUserLoginActivity = 0x9cf9;
static const Word strpre_TitleUserActivity = 0x9cfa;
static const Word strqrlItem = 0x9cfb;
static const Word strqrlDate = 0x9cfc;
static const Word strrepTitleCompUtil = 0x9cfd;
static const Word strbtnPrint = 0x9cfe;
static const Word strMaxCurrentUsersReached = 0x9cff;

}	/* namespace Users_res */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Users_res;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// users_res
