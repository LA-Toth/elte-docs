// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rpt_permissions.pas' rev: 5.00

#ifndef rpt_permissionsHPP
#define rpt_permissionsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <QuickRpt.hpp>	// Pascal unit
#include <Qrctrls.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rpt_permissions
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Trpt_UPPermissions;
class PASCALIMPLEMENTATION Trpt_UPPermissions : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Quickrpt::TQuickRep* QuickRep;
	Quickrpt::TQRBand* PageFooterBand1;
	Qrctrls::TQRSysData* QRSysData2;
	Quickrpt::TQRBand* DetailBand1;
	Qrctrls::TQRMemo* qrmPermissions;
	Qrctrls::TQRLabel* qrlWho;
	Qrctrls::TQRLabel* qrlModule;
	Qrctrls::TQRLabel* QRLabel1;
	Qrctrls::TQRLabel* QRLabel2;
	Qrctrls::TQRLabel* QRLabel3;
	Qrctrls::TQRShape* QRShape1;
	Qrctrls::TQRDBText* QRDBText1;
	Qrctrls::TQRSysData* QRSysData1;
	Qrctrls::TQRShape* QRShape2;
	void __fastcall QRDBText1Print(System::TObject* sender, AnsiString &Value);
	void __fastcall DetailBand1BeforePrint(Quickrpt::TQRCustomBand* Sender, bool &PrintBand);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual Trpt_UPPermissions(Classes::TComponent* AOwner) : 
		Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual Trpt_UPPermissions(Classes::TComponent* AOwner
		, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~Trpt_UPPermissions(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall Trpt_UPPermissions(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Trpt_UPPermissions* rpt_UPPermissions;

}	/* namespace Rpt_permissions */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Rpt_permissions;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rpt_permissions
