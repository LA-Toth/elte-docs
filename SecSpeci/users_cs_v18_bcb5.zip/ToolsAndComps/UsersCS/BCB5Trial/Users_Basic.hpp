// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'users_basic.pas' rev: 5.00

#ifndef users_basicHPP
#define users_basicHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <ActnList.hpp>	// Pascal unit
#include <AxCtrls.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <DBGrids.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <users_res.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Users_basic
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS EUsersError;
class PASCALIMPLEMENTATION EUsersError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EUsersError(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EUsersError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EUsersError(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EUsersError(int Ident, const System::TVarRec * Args, 
		const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EUsersError(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EUsersError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EUsersError(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EUsersError(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EUsersError(void) { }
	#pragma option pop
	
};


class DELPHICLASS TUser;
class PASCALIMPLEMENTATION TUser : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	AnsiString FUserName;
	AnsiString FRealName;
	int FUserId;
	AnsiString FPassword;
	System::TDateTime FLastPwdChange;
	System::TDateTime FExpirationDate;
	AnsiString FUserExpire;
	AnsiString FUserActive;
	int FProfileId;
	AnsiString FProfile;
	AnsiString FAuditMode;
	AnsiString FUserIsAdmin;
	AnsiString FAdditionalInfo;
	System::TDateTime __fastcall GetLastPwdChange(void);
	System::TDateTime __fastcall GetExpirationDate(void);
	bool __fastcall GetUserExpire(void);
	bool __fastcall GetUserActive(void);
	bool __fastcall GetAuditMode(void);
	bool __fastcall GetUserIsAdmin(void);
	AnsiString __fastcall GetProfileName(int ProfileId);
	
public:
	__fastcall TUser(void);
	__fastcall virtual ~TUser(void);
	__property AnsiString UserName = {read=FUserName};
	__property int UserId = {read=FUserId, nodefault};
	__property AnsiString Password = {read=FPassword};
	__property AnsiString RealName = {read=FRealName};
	__property System::TDateTime LastPwdChange = {read=GetLastPwdChange};
	__property System::TDateTime ExpirationDate = {read=GetExpirationDate};
	__property bool UserExpire = {read=GetUserExpire, nodefault};
	__property bool UserActive = {read=GetUserActive, nodefault};
	__property AnsiString Profile = {read=FProfile};
	__property int ProfileId = {read=FProfileId, nodefault};
	__property bool AuditMode = {read=GetAuditMode, nodefault};
	__property bool UserIsAdmin = {read=GetUserIsAdmin, nodefault};
	__property AnsiString AdditionalInfo = {read=FAdditionalInfo};
};


typedef void __fastcall (__closure *TUserLoginEvent)(AnsiString &UserName, AnsiString &Password, Forms::TModalResult 
	&ModalResult);

typedef void __fastcall (__closure *TNewUserEvent)(int USER_ID, bool &NewUserOK);

typedef void __fastcall (__closure *TGetDateTimeEvent)(System::TDateTime &DateTime);

#pragma option push -b-
enum TLoginStatus { lsInvalidUserName, lsInvalidPassword, lsValidUser, lsUserInactive };
#pragma option pop

typedef void __fastcall (__closure *TAfterPostUserDataEvent)(AnsiString UserName, AnsiString RealName
	, AnsiString Password, int UserId, int ProfileId);

typedef void __fastcall (__closure *TGetActualUserId)(int &User_Id);

typedef void __fastcall (__closure *TShowAdditionalInfo)(Forms::TForm* &aForm, Extctrls::TPanel* &aPanel
	, TGetActualUserId GetActualUserId);

typedef void __fastcall (__closure *TValidatePasswordEvent)(AnsiString Password, bool &Accept);

typedef void __fastcall (__closure *TRegisterComponentsAtRunTime)(void);

typedef void __fastcall (__closure *TLoginEvent)(void);

typedef void __fastcall (__closure *TOnTimeOut)(void);

class DELPHICLASS TUsersBasic;
class PASCALIMPLEMENTATION TUsersBasic : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TUser* FActualUser;
	bool FAutoLogin;
	bool FTablesOpened;
	AnsiString FAppKey;
	TUserLoginEvent FOnLogin;
	TGetDateTimeEvent FOnGetDateTime;
	Classes::TStringList* FFormList;
	bool FLastLoginOk;
	int FMinPwdSize;
	Classes::TNotifyEvent FFormOnDestroy;
	TNewUserEvent FOnNewUser;
	TAfterPostUserDataEvent FAfterPostUserData;
	int FTimeOut;
	int FMaxBadLogins;
	int FMaxDaysInnative;
	bool FDisableUser;
	int FMaxPwdHistory;
	bool FAllowMultipleLogins;
	TShowAdditionalInfo FShowAdditionalInfo;
	bool FFileNames83DOS;
	Extctrls::TTimer* InternalTimer;
	TValidatePasswordEvent FValidatePassword;
	bool FUserSectionActive;
	TRegisterComponentsAtRunTime FRegisterComponentsAtRunTime;
	int FMaxCurrentUsers;
	bool FHaltOnReachMaxCurrentUsers;
	TLoginEvent FBeforeLogin;
	TLoginEvent FWhileDoLogin;
	TLoginEvent FAfterLogin;
	TOnTimeOut FOnTimeOut;
	AnsiString FVersion;
	void __fastcall InternalTimeOut(System::TObject* Sender);
	void __fastcall DoAutoLogin(void);
	bool __fastcall ForcesPasswordChange(void);
	void __fastcall SetAppKey(AnsiString NewAppKey);
	void __fastcall TraceLoginAndDestroyForm(System::TObject* Sender);
	void __fastcall SetFormList(Classes::TStringList* Value);
	void __fastcall DoAppMessage(tagMSG &Msg, bool &Handled);
	void __fastcall SetVersion(const AnsiString Value);
	
public:
	__property bool LastLoginOk = {read=FLastLoginOk, nodefault};
	__property TUser* ActualUser = {read=FActualUser, write=FActualUser};
	__property bool FileNames83DOS = {read=FFileNames83DOS, write=FFileNames83DOS, nodefault};
	__property int MaxBadLogins = {read=FMaxBadLogins, write=FMaxBadLogins, nodefault};
	__fastcall virtual TUsersBasic(Classes::TComponent* aOwner);
	__fastcall virtual ~TUsersBasic(void);
	virtual void __fastcall Loaded(void);
	bool __fastcall Login(void);
	void __fastcall Logout(void);
	void __fastcall ChangeUserPassword(void);
	TLoginStatus __fastcall VerifyUser(AnsiString UserName, AnsiString Password);
	TUser* __fastcall GetUserInfo(AnsiString UserName);
	virtual Classes::TComponent* __fastcall GetDatabase(void);
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual bool __fastcall InTransaction(void);
	virtual void __fastcall TraceLogin(void);
	virtual void __fastcall TraceLogout(void);
	void __fastcall ApplySecurityDataModules(void);
	System::TDateTime __fastcall GetDateTime(void);
	void __fastcall UpdateFormsAndComps(void);
	void __fastcall UsersAdm(void);
	void __fastcall UsersAdmCentral(void);
	void __fastcall AddComponentsAtRunTime(AnsiString FormName, AnsiString ComponentName, AnsiString ComponentCaption
		, AnsiString ComponentParent);
	int __fastcall GetNumberOfCurrentUsers(void);
	
__published:
	__property TUserLoginEvent OnLogin = {read=FOnLogin, write=FOnLogin};
	__property TGetDateTimeEvent OnGetDateTime = {read=FOnGetDateTime, write=FOnGetDateTime};
	__property TNewUserEvent OnNewUser = {read=FOnNewUser, write=FOnNewUser};
	__property TAfterPostUserDataEvent AfterPostUserData = {read=FAfterPostUserData, write=FAfterPostUserData
		};
	__property TShowAdditionalInfo OnShowAdditionalInfo = {read=FShowAdditionalInfo, write=FShowAdditionalInfo
		};
	__property TValidatePasswordEvent OnValidatePassword = {read=FValidatePassword, write=FValidatePassword
		};
	__property TRegisterComponentsAtRunTime RegisterComponentsAtRunTime = {read=FRegisterComponentsAtRunTime
		, write=FRegisterComponentsAtRunTime};
	__property bool AutoLogin = {read=FAutoLogin, write=FAutoLogin, default=0};
	__property AnsiString AppKey = {read=FAppKey, write=SetAppKey};
	__property int MinPwdSize = {read=FMinPwdSize, write=FMinPwdSize, default=6};
	__property Classes::TStringList* FormList = {read=FFormList, write=SetFormList};
	__property int MaxCurrentUsers = {read=FMaxCurrentUsers, write=FMaxCurrentUsers, default=0};
	__property bool HaltOnReachMaxCurrentUsers = {read=FHaltOnReachMaxCurrentUsers, write=FHaltOnReachMaxCurrentUsers
		, default=0};
	__property TLoginEvent BeforeLogin = {read=FBeforeLogin, write=FBeforeLogin};
	__property TLoginEvent WhileDoLogin = {read=FWhileDoLogin, write=FWhileDoLogin};
	__property TLoginEvent AfterLogin = {read=FAfterLogin, write=FAfterLogin};
	__property TOnTimeOut OnTimeOut = {read=FOnTimeOut, write=FOnTimeOut};
	__property AnsiString Version = {read=FVersion, write=SetVersion};
};


#pragma option push -b-
enum TComponentStatus { csEnabledVisible, csDisabledVisible, csInvisible, csNotRegistered };
#pragma option pop

struct TComponentInfo
{
	AnsiString Name;
	AnsiString Caption;
	int Id;
	Classes::TNotifyEvent Event;
	TComponentStatus ComponentStatus;
} ;

class DELPHICLASS TFieldEventList;
class PASCALIMPLEMENTATION TFieldEventList : public Classes::TList 
{
	typedef Classes::TList inherited;
	
public:
	int __fastcall FieldIndexOf(AnsiString FieldName);
public:
	#pragma option push -w-inl
	/* TList.Destroy */ inline __fastcall virtual ~TFieldEventList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TFieldEventList(void) : Classes::TList() { }
	#pragma option pop
	
};


typedef void __fastcall (__closure *TApplySecurity)(System::TObject* Sender, const TComponentInfo &ComponentInfo
	, bool &Handled);

class DELPHICLASS TUsersReg;
class PASCALIMPLEMENTATION TUsersReg : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FFormName;
	AnsiString FFormCaption;
	Classes::TStringList* FComponentList;
	TUsersBasic* FSecurityComponent;
	Classes::TNotifyEvent FFormShow;
	Classes::TNotifyEvent FDataModuleCreate;
	TFieldEventList* FFieldEventList;
	TApplySecurity FOnApplySecurity;
	void __fastcall SetFormCaption(AnsiString Value);
	HIDESBASE int __fastcall GetComponentCount(void);
	void __fastcall ProcessDBNavigator(Dbctrls::TDBNavigator* DBNavigator, const TComponentInfo &ComponentInfo
		);
	void __fastcall ProcessDBGrid(Dbgrids::TDBGrid* DBGrid, const TComponentInfo &ComponentInfo);
	void __fastcall ProcessCoolBar(Comctrls::TCoolBar* CoolBar, const TComponentInfo &ComponentInfo);
	void __fastcall ProcessDataset(Db::TDataSet* Dataset, const TComponentInfo &ComponentInfo);
	void __fastcall ProcessTControl(Classes::TComponent* Component, const TComponentInfo &ComponentInfo
		);
	void __fastcall ProcessMenuItem(Menus::TMenuItem* MenuItem, const TComponentInfo &ComponentInfo);
	void __fastcall ProcessToolBar(Comctrls::TToolBar* ToolBar, const TComponentInfo &ComponentInfo);
	void __fastcall ProcessFrame(Forms::TFrame* Frame);
	void __fastcall ProcessActionList(Actnlist::TActionList* ActionList);
	void __fastcall ProcessComponent(System::TObject* Component, AnsiString CompName);
	void __fastcall ProcessSubClasses(System::TObject* Component);
	void __fastcall SetEssentialProperties(System::TObject* Component, int Enabled, int Visible, int ReadOnly
		);
	void __fastcall MakeFieldInvisible(Db::TField* Sender, AnsiString &Text, bool DisplayText);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall DataModuleCreate(System::TObject* Sender);
	bool __fastcall HandleSecurity(System::TObject* Sender, const TComponentInfo &ComponentInfo);
	void __fastcall SetSecurityComponent(TUsersBasic* Value);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	
protected:
	int FFormId;
	Classes::TStringList* FComponentIdList;
	virtual void __fastcall Loaded(void);
	
public:
	__property int ComponentCount = {read=GetComponentCount, nodefault};
	__fastcall virtual TUsersReg(Classes::TComponent* Owner);
	__fastcall virtual ~TUsersReg(void);
	void __fastcall ApplySecurity(void);
	virtual void __fastcall Audit(AnsiString ComponentName, AnsiString AdditionalInfo1, AnsiString AdditionalInfo2
		);
	TComponentInfo __fastcall GetComponentInfo(AnsiString CompName);
	TComponentInfo __fastcall GetUserComponentInfo(AnsiString UserName, AnsiString CompName);
	
__published:
	__property AnsiString FormName = {read=FFormName, write=FFormName};
	__property AnsiString FormCaption = {read=FFormCaption, write=SetFormCaption};
	__property Classes::TStringList* ComponentList = {read=FComponentList, write=FComponentList};
	__property TUsersBasic* SecurityComponent = {read=FSecurityComponent, write=SetSecurityComponent};
	__property TApplySecurity OnApplySecurity = {read=FOnApplySecurity, write=FOnApplySecurity};
};


struct TLoginTraceInfo
{
	System::TDateTime LoginDateTime;
	System::TDateTime LogoutDateTime;
	int BadLoginAttempts;
	int UserId;
} ;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString ComputerName;
extern PACKAGE TLoginTraceInfo LoginTraceInfo;
extern PACKAGE AnsiString __fastcall GetLeft(AnsiString s);
extern PACKAGE AnsiString __fastcall GetRigth(AnsiString s);
extern PACKAGE AnsiString __fastcall GetCompList(AnsiString s);

}	/* namespace Users_basic */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Users_basic;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// users_basic
