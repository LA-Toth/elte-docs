// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'dtm_users.pas' rev: 5.00

#ifndef dtm_usersHPP
#define dtm_usersHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <users_res.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dtm_users
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUsers;
class PASCALIMPLEMENTATION TUsers : public Forms::TDataModule 
{
	typedef Forms::TDataModule inherited;
	
__published:
	Db::TDataSource* dsUsers;
	Db::TDataSource* dsProfiles;
	Db::TDataSource* dsComps;
	Db::TDataSource* dsHistory;
	Db::TDataSource* dsUAccess;
	Db::TDataSource* dsPAccess;
	Dbtables::TQuery* GenerateId;
	Dbtables::TQuery* ProfNull;
	Dbtables::TQuery* DelUserFromUAccess;
	Dbtables::TQuery* DelCompsFromUAccess;
	Dbtables::TQuery* DelProfsFromPAccess;
	Dbtables::TQuery* DelCompsFromPAccess;
	Dbtables::TQuery* DelUHistory;
	Dbtables::TQuery* UpdateUFromProfile;
	Dbtables::TQuery* qryUsers;
	Dbtables::TQuery* qryProfiles;
	Dbtables::TQuery* qryHistory;
	Dbtables::TQuery* qryUAccess;
	Dbtables::TQuery* qryAudit;
	Db::TStringField* qryUsersUSER_NAME;
	Db::TStringField* qryUsersREAL_NAME;
	Db::TStringField* qryUsersUSER_PWD;
	Db::TStringField* qryUsersPROFILE;
	Db::TStringField* qryUsersCalcUserActive;
	Db::TStringField* qryProfilesPROF_DESCRIPTION;
	Db::TStringField* qryProfilesMUST_CHANGE_PWD;
	Db::TStringField* qryProfilesCalcMustChangePwd;
	Db::TDataSource* dsAudit;
	Dbtables::TQuery* qryUserName;
	Db::TDataSource* dsUserName;
	Db::TStringField* qryUsersAUDIT_MODE;
	Db::TStringField* qryProfilesAUDIT_MODE;
	Dbtables::TQuery* qryUserInfo;
	Db::TDataSource* dsUserInfo;
	Db::TStringField* qryUserInfoAPP_KEY;
	Db::TStringField* qryUserInfoUSER_EXPIRE;
	Db::TStringField* qryUserInfoUSER_ACTIVE;
	Dbtables::TQuery* qryAddUserInfo;
	Dbtables::TQuery* qryDelUserInfo;
	Db::TFloatField* qryUsersUSER_ID;
	Db::TFloatField* qryUsersPROFILE_ID;
	Db::TFloatField* qryProfilesPROF_ID;
	Db::TFloatField* qryProfilesINTERVAL_CHANGE_PWD;
	Db::TFloatField* qryUserInfoUSER_ID;
	Db::TFloatField* qryUsersLAST_PWD_CHANGE;
	Db::TFloatField* qryUserInfoEXPIRATION_DATE;
	Dbtables::TQuery* UpdateUFromProfileAccess;
	Dbtables::TQuery* qryForms;
	Db::TDataSource* dtsForms;
	Db::TStringField* qryFormsFORM_NAME;
	Db::TFloatField* qryFormsFORM_ID;
	Db::TStringField* qryFormsFORM_CAPTION;
	Db::TStringField* qryFormsAPP_KEY;
	Db::TStringField* qryUserInfoUSER_IS_ADMIN;
	Db::TStringField* qryUAccessAPP_KEY;
	Db::TFloatField* qryUAccessFORM_ID;
	Db::TFloatField* qryUAccessCOMP_ID;
	Db::TFloatField* qryUAccessUSER_ID;
	Db::TStringField* qryUAccessAUTHORIZED;
	Dbtables::TQuery* qryPAccess;
	Db::TStringField* qryPAccessAPP_KEY;
	Db::TFloatField* qryPAccessFORM_ID;
	Db::TFloatField* qryPAccessCOMP_ID;
	Db::TFloatField* qryPAccessPROF_ID;
	Db::TStringField* qryPAccessAUTHORIZED;
	Dbtables::TQuery* qryListComps;
	Db::TStringField* StringField1;
	Db::TFloatField* FloatField1;
	Db::TStringField* StringField2;
	Db::TFloatField* FloatField2;
	Db::TStringField* StringField3;
	Db::TFloatField* FloatField3;
	Dbtables::TQuery* qryListForms;
	Db::TStringField* StringField4;
	Db::TFloatField* FloatField4;
	Db::TStringField* StringField5;
	Db::TStringField* StringField6;
	Dbtables::TQuery* qryUsersAdmins;
	Dbtables::TQuery* qryLoginTrace;
	Db::TDataSource* dtsLoginTrace;
	Db::TStringField* qryLoginTraceAPP_KEY;
	Db::TFloatField* qryLoginTraceUSER_ID;
	Db::TStringField* qryLoginTraceCOMPUTER_NAME;
	Db::TFloatField* qryLoginTraceLOGIN_DATE_TIME;
	Db::TFloatField* qryLoginTraceLOGOUT_DATE_TIME;
	Db::TFloatField* qryAuditFORM_ID;
	Db::TStringField* qryAuditCOMP_CAPTION;
	Db::TFloatField* qryAuditCOMP_ID;
	Db::TStringField* qryAuditUSERCS_NAME;
	Db::TFloatField* qryAuditUSER_ID;
	Db::TFloatField* qryAuditDATE_UTIL;
	Db::TStringField* qryAuditCOMPUTER_NAME;
	Db::TStringField* qryAuditADDITIONAL_INFO1;
	Db::TStringField* qryAuditADDITIONAL_INFO2;
	Dbtables::TQuery* qryDeleteUserAudit;
	Db::TStringField* qryAuditAPP_KEY;
	Dbtables::TQuery* qryComps;
	Db::TStringField* qryCompsAPP_KEY;
	Db::TFloatField* qryCompsFORM_ID;
	Db::TStringField* qryCompsCOMP_NAME;
	Db::TFloatField* qryCompsCOMP_ID;
	Db::TStringField* qryCompsCOMP_CAPTION;
	Db::TFloatField* qryCompsPARENT_ID;
	Dbtables::TUpdateSQL* updtUsers;
	Dbtables::TUpdateSQL* updtUserInfo;
	Dbtables::TQuery* qryDeleteLoginTrace;
	Dbtables::TUpdateSQL* updtUAccess;
	Dbtables::TUpdateSQL* updtPAccess;
	Dbtables::TUpdateSQL* updtComps;
	Dbtables::TQuery* qryCurrentUsers;
	Db::TDataSource* dtsCurrentUsers;
	Db::TFloatField* qryCurrentUsersLOGIN_DATE_TIME;
	Db::TStringField* qryCurrentUsersCOMPUTER_NAME;
	Db::TStringField* qryCurrentUsersUSERCS_NAME;
	Db::TDataSource* dtsApplication;
	Dbtables::TQuery* qryApplication;
	Db::TStringField* qryApplicationAPP_KEY;
	Db::TFloatField* qryApplicationTIME_OUT;
	Db::TFloatField* qryApplicationMAX_BAD_LOGINS;
	Db::TFloatField* qryApplicationMAX_DAYS_INNATIVE;
	Db::TStringField* qryApplicationDISABLE_USER;
	Db::TFloatField* qryApplicationMAX_PWD_HISTORY;
	Db::TStringField* qryApplicationALLOW_MULTIPLE_LOGINS;
	Dbtables::TUpdateSQL* updtAudit;
	Db::TStringField* qryUserInfoADDITIONAL_INFO;
	Dbtables::TQuery* qryAux;
	Db::TStringField* qryCurrentUsersPROF_DESCRIPTION;
	Db::TFloatField* qryCurrentUsersPROFILE_ID;
	void __fastcall qryUsersBeforeDelete(Db::TDataSet* DataSet);
	void __fastcall qryUsersAfterDelete(Db::TDataSet* DataSet);
	void __fastcall qryProfilesBeforeDelete(Db::TDataSet* DataSet);
	void __fastcall qryProfilesAfterDelete(Db::TDataSet* DataSet);
	void __fastcall qryUsersBeforePost(Db::TDataSet* DataSet);
	void __fastcall qryProfilesBeforePost(Db::TDataSet* DataSet);
	void __fastcall qryCompsBeforePost(Db::TDataSet* DataSet);
	void __fastcall qryUsersAfterOpen(Db::TDataSet* DataSet);
	void __fastcall qryProfilesAfterInsert(Db::TDataSet* DataSet);
	void __fastcall qryCompsBeforeDelete(Db::TDataSet* DataSet);
	void __fastcall qryProfilesCalcFields(Db::TDataSet* DataSet);
	void __fastcall qryUsersCalcFields(Db::TDataSet* DataSet);
	void __fastcall UsersCreate(System::TObject* Sender);
	void __fastcall qryUsersBeforeEdit(Db::TDataSet* DataSet);
	void __fastcall qryUsersAfterPost(Db::TDataSet* DataSet);
	void __fastcall qryProfilesAfterPost(Db::TDataSet* DataSet);
	void __fastcall qryUsersBeforeInsert(Db::TDataSet* DataSet);
	void __fastcall qryUsersAfterScroll(Db::TDataSet* DataSet);
	void __fastcall qryUsersLAST_PWD_CHANGEGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText
		);
	void __fastcall qryUsersLAST_PWD_CHANGESetText(Db::TField* Sender, const AnsiString Text);
	void __fastcall qryHistoryCHANGE_DATEGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText
		);
	void __fastcall qryFormsBeforePost(Db::TDataSet* DataSet);
	void __fastcall qryUsersAfterInsert(Db::TDataSet* DataSet);
	void __fastcall qryLoginTraceLOGIN_DATE_TIMEGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText
		);
	void __fastcall qryLoginTraceLOGOUT_DATE_TIMEGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText
		);
	void __fastcall qryAuditDATE_UTILGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText);
	void __fastcall qryUserInfoAfterPost(Db::TDataSet* DataSet);
	void __fastcall qryUserInfoAfterEdit(Db::TDataSet* DataSet);
	void __fastcall qryCurrentUsersLOGIN_DATE_TIMEGetText(Db::TField* Sender, AnsiString &Text, bool DisplayText
		);
	void __fastcall qryProfilesAfterEdit(Db::TDataSet* DataSet);
	
private:
	bool FileName83DOS;
	bool __fastcall VerificaKeyViolation(AnsiString Table, AnsiString Field, AnsiString Value, AnsiString 
		msg);
	
public:
	int PROF_ID;
	AnsiString AppKey;
	void __fastcall ChangeFileNames(bool Use83DOS);
	void __fastcall ApplyUpdatesDataset(Dbtables::TQuery* Dataset);
	void __fastcall SetDatabaseComponent(Classes::TComponent* Database);
public:
	#pragma option push -w-inl
	/* TDataModule.Create */ inline __fastcall virtual TUsers(Classes::TComponent* AOwner) : Forms::TDataModule(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TDataModule.CreateNew */ inline __fastcall virtual TUsers(Classes::TComponent* AOwner, int Dummy
		) : Forms::TDataModule(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TDataModule.Destroy */ inline __fastcall virtual ~TUsers(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint Invisivel = 0x1;
static const Shortint Desabilitado = 0x2;
#define Audit83 "\"AUDIT.DB\""
#define History83 "\"HISTORY.DB\""
#define Profiles83 "\"PROFILES.DB\""
#define Forms83 "\"FORMS.DB\""
#define Comps83 "\"COMPS.DB\""
#define Users83 "\"USERS.DB\""
#define UAccess83 "\"UACCESS.DB\""
#define PAccess83 "\"PACCESS.DB\""
#define UserInfo83 "\"USERINFO.DB\""
#define LoginTrace83 "\"LGNTRACE.DB\""
#define AppInfo83 "\"APPINFO.DB\""
#define Audit "UCS_AUDIT"
#define History "UCS_HISTORY"
#define Profiles "UCS_PROFILES"
#define _Forms "UCS_FORMS"
#define Comps "UCS_COMPS"
#define _Users "UCS_USERS"
#define UAccess "UCS_UACCESS"
#define PAccess "UCS_PACCESS"
#define UserInfo "UCS_USERINFO"
#define LoginTrace "UCS_LOGIN_TRACE"
#define AppInfo "UCS_APP_INFO"
extern PACKAGE TUsers* Users;

}	/* namespace Dtm_users */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dtm_users;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// dtm_users
