// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'new_user.pas' rev: 5.00

#ifndef new_userHPP
#define new_userHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <users_basic.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <users_res.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace New_user
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrmNewUser;
class PASCALIMPLEMENTATION TfrmNewUser : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel1;
	Extctrls::TPanel* Panel3;
	Stdctrls::TLabel* lblUSER_NAME;
	Stdctrls::TLabel* lblREAL_NAME;
	Stdctrls::TLabel* lblPASSWORD;
	Stdctrls::TLabel* lblPROFILE;
	Dbctrls::TDBEdit* DBEdit1;
	Dbctrls::TDBEdit* DBEdit2;
	Dbctrls::TDBEdit* DBEdit3;
	Dbctrls::TDBLookupComboBox* DBLookupComboBox1;
	Stdctrls::TButton* OKBtn;
	Stdctrls::TButton* CancelBtn;
	Dbctrls::TDBCheckBox* cbxAUDIT_MODE;
	void __fastcall OKBtnClick(System::TObject* Sender);
	void __fastcall NomeUsuarioExit(System::TObject* Sender);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall FormActivate(System::TObject* Sender);
	void __fastcall DBEdit3Exit(System::TObject* Sender);
	
public:
	int MinPwdSize;
	Users_basic::TValidatePasswordEvent ValidatePassword;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrmNewUser(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrmNewUser(Classes::TComponent* AOwner, int 
		Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrmNewUser(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrmNewUser(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrmNewUser* frmNewUser;

}	/* namespace New_user */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace New_user;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// new_user
