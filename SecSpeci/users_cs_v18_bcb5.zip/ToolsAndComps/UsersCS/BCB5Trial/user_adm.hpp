// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'user_adm.pas' rev: 5.00

#ifndef user_admHPP
#define user_admHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Qrctrls.hpp>	// Pascal unit
#include <QuickRpt.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <ToolWin.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <users_res.hpp>	// Pascal unit
#include <users_basic.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <DBGrids.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace User_adm
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUserAdministration;
class PASCALIMPLEMENTATION TUserAdministration : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel1;
	Comctrls::TPageControl* PageControl;
	Comctrls::TTabSheet* tsUsers;
	Comctrls::TPageControl* pcUsers;
	Comctrls::TTabSheet* tsUsersList;
	Dbgrids::TDBGrid* DBGridUsers;
	Comctrls::TTabSheet* tsUsersData;
	Stdctrls::TLabel* lblLAST_PWD_CHANGE;
	Dbctrls::TDBEdit* DBEdit4;
	Comctrls::TTabSheet* tsProfiles;
	Comctrls::TTabSheet* tsPrograms;
	Stdctrls::TLabel* lblUSER_NAME;
	Stdctrls::TLabel* lblREAL_NAME;
	Stdctrls::TLabel* lblPASSWORD;
	Stdctrls::TLabel* lblEXPIRATION_DATE;
	Stdctrls::TLabel* lblPROFILE;
	Dbctrls::TDBEdit* DBEdit1;
	Dbctrls::TDBEdit* DBEdit2;
	Dbctrls::TDBEdit* DBEdit3;
	Dbctrls::TDBCheckBox* cbxUSER_EXPIRE;
	Dbctrls::TDBCheckBox* cbxUSER_ACTIVE;
	Dbctrls::TDBLookupComboBox* dblkProfileName;
	Stdctrls::TButton* btnChangePassword;
	Comctrls::TPageControl* pcPrograms;
	Comctrls::TTabSheet* tsUsersProgs;
	Dbgrids::TDBGrid* DBGridUsersProgs;
	Comctrls::TPageControl* pcProfiles;
	Comctrls::TTabSheet* tsProfilesList;
	Dbgrids::TDBGrid* DBGridProfiles;
	Comctrls::TTabSheet* tsProfilesData;
	Extctrls::TPanel* Panel4;
	Extctrls::TPanel* PanelPwdHistory;
	Dbctrls::TDBNavigator* DBNavigator1;
	Dbgrids::TDBGrid* DBGridPwdHistory;
	Stdctrls::TLabel* lblPROF_DESCRIPTION;
	Dbctrls::TDBEdit* DBEdit5;
	Stdctrls::TLabel* lblINTERVAL_CHANGE_PWD;
	Dbctrls::TDBEdit* DBEdit6;
	Dbctrls::TDBCheckBox* cbxMUST_CHANGE_PWD;
	Dbgrids::TDBGrid* DBGridProfilesProgs;
	Extctrls::TPanel* ToolBar;
	Buttons::TSpeedButton* sbNewUser;
	Buttons::TSpeedButton* sbUserAccess;
	Buttons::TSpeedButton* sbChangeUserData;
	Buttons::TSpeedButton* sbDeleteUser;
	Extctrls::TPanel* Panel3;
	Buttons::TSpeedButton* sbNewProfile;
	Buttons::TSpeedButton* sbProfileAccess;
	Buttons::TSpeedButton* sbChangeProfileData;
	Buttons::TSpeedButton* sbDeleteProfile;
	Extctrls::TPanel* Panel2;
	Comctrls::TTreeView* CompList;
	Extctrls::TPanel* Panel6;
	Extctrls::TPanel* PanelAboveProgs;
	Buttons::TSpeedButton* sbApply;
	Buttons::TSpeedButton* sbRestore;
	Buttons::TSpeedButton* sbRestoreProfile;
	Comctrls::TDateTimePicker* DBDateTimePicker1;
	Dbctrls::TDBCheckBox* cbxAUDIT_MODE;
	Dbctrls::TDBCheckBox* cbxAUDIT_MODEProfile;
	Dbctrls::TDBNavigator* DBNavigator2;
	Dbctrls::TDBNavigator* DBNavigator3;
	Comctrls::TTabSheet* tsAudit;
	Comctrls::TPageControl* pcAudit;
	Comctrls::TTabSheet* tsUserActivity;
	Comctrls::TTabSheet* tsCompUtilization;
	Extctrls::TPanel* Panel5;
	Extctrls::TPanel* Panel7;
	Dbgrids::TDBGrid* DBGridAudUsers;
	Dbgrids::TDBGrid* DBGridAudComps;
	Dbctrls::TDBNavigator* DBNavigator4;
	Dbctrls::TDBLookupComboBox* dblkUserName;
	Dbctrls::TDBLookupComboBox* dblkCompName;
	Dbctrls::TDBNavigator* DBNavigator5;
	Stdctrls::TGroupBox* gbxPeriodActivities;
	Stdctrls::TLabel* lblFrom;
	Stdctrls::TLabel* lblTo;
	Comctrls::TDateTimePicker* dtpkInicioU;
	Comctrls::TDateTimePicker* dtpkFimU;
	Stdctrls::TLabel* lblUser;
	Stdctrls::TGroupBox* gbxPeriodActivities2;
	Stdctrls::TLabel* lblFrom2;
	Comctrls::TDateTimePicker* dtpkInicioP;
	Comctrls::TDateTimePicker* dtpkFimP;
	Stdctrls::TLabel* lblComponent;
	Stdctrls::TLabel* lblTo2;
	Buttons::TSpeedButton* sbDeleteAuditUser;
	Buttons::TSpeedButton* sbDeleteAuditProg;
	Stdctrls::TGroupBox* gbxFormList;
	Dbctrls::TDBLookupComboBox* dblkForms;
	Dbctrls::TDBCheckBox* cbxUSER_IS_ADMIN;
	Comctrls::TTabSheet* tsLoginActivity;
	Dbgrids::TDBGrid* dbgLoginActivity;
	Extctrls::TPanel* Panel8;
	Stdctrls::TLabel* lblUser1;
	Buttons::TSpeedButton* sbDeleteUserLoginActivity;
	Dbctrls::TDBNavigator* DBNavigator6;
	Dbctrls::TDBLookupComboBox* dblkUserName2;
	Stdctrls::TGroupBox* gbxPeriodActivities1;
	Stdctrls::TLabel* lblFrom1;
	Stdctrls::TLabel* lblTo1;
	Comctrls::TDateTimePicker* dtpkInicioLT;
	Comctrls::TDateTimePicker* dtpkFimLT;
	Comctrls::TTabSheet* tsProfilesProgs;
	Dbctrls::TDBLookupComboBox* dblkForms1;
	Stdctrls::TLabel* lblForm1;
	Stdctrls::TLabel* lblForm2;
	Dbctrls::TDBLookupComboBox* dblkForms2;
	Extctrls::TPanel* Panel9;
	Extctrls::TPanel* Panel10;
	Stdctrls::TGroupBox* gbxAddInfo1;
	Stdctrls::TGroupBox* gbxAddInfo2;
	Forms::TScrollBox* ScrollBox1;
	Dbctrls::TDBText* DBText1;
	Dbctrls::TDBText* DBText2;
	Forms::TScrollBox* ScrollBox2;
	Dbctrls::TDBText* DBText3;
	Dbctrls::TDBText* DBText4;
	Extctrls::TBevel* Bevel1;
	Extctrls::TBevel* Bevel2;
	Buttons::TSpeedButton* sbPrintUserList;
	Buttons::TSpeedButton* sbPrintProfileList;
	Buttons::TSpeedButton* sbPrintUserAccess;
	Buttons::TSpeedButton* sbPrintProfileAccess;
	Buttons::TSpeedButton* sbPrintUserLoginActivity;
	Buttons::TSpeedButton* sbPrintUserActivity;
	Buttons::TSpeedButton* sbPrintCompUtilization;
	Comctrls::TTabSheet* tabAdditionalInfo;
	Menus::TPopupMenu* PopupTreeView;
	Menus::TMenuItem* AllEnabled;
	Menus::TMenuItem* AllInvisible;
	Menus::TMenuItem* AllDisabled;
	Menus::TMenuItem* N1;
	Menus::TMenuItem* ShowLegenda;
	Controls::TImageList* ImageList;
	Extctrls::TPanel* PanelLegenda;
	Buttons::TSpeedButton* SpeedButton1;
	Buttons::TSpeedButton* SpeedButton2;
	Buttons::TSpeedButton* SpeedButton3;
	Extctrls::TPanel* pnlLegendaEnabled;
	Extctrls::TPanel* pnlTopLegenda;
	Extctrls::TPanel* pnlLegendaOnlyVisible;
	Extctrls::TPanel* pnlLegendaInvisible;
	Buttons::TBitBtn* btnLegenda;
	Comctrls::TTabSheet* tsCurrentUsers;
	Dbgrids::TDBGrid* dbgCurrentUsers;
	Extctrls::TPanel* Panel11;
	Stdctrls::TButton* btnRefreshCurrentUsers;
	Comctrls::TTabSheet* tabAppConfig;
	Stdctrls::TLabel* lblTimeOut;
	Dbctrls::TDBEdit* DBEdit7;
	Stdctrls::TLabel* lblMaxBadLogins;
	Dbctrls::TDBEdit* DBEdit8;
	Stdctrls::TLabel* lblInativeDays;
	Dbctrls::TDBEdit* DBEdit9;
	Stdctrls::TLabel* lblMaxPwdHistory;
	Dbctrls::TDBEdit* DBEdit11;
	Dbctrls::TDBCheckBox* dbcbxDisableUser;
	Dbctrls::TDBCheckBox* dbcbxMultipleLogins;
	Menus::TMenuItem* N2;
	Menus::TMenuItem* PrintPermissions;
	void __fastcall FormActivate(System::TObject* Sender);
	void __fastcall sbNewUserClick(System::TObject* Sender);
	void __fastcall sbChangeUserDataClick(System::TObject* Sender);
	void __fastcall cbxUSER_EXPIREClick(System::TObject* Sender);
	void __fastcall tsUsersDataEnter(System::TObject* Sender);
	void __fastcall tsUsersDataExit(System::TObject* Sender);
	void __fastcall sbUserAccessClick(System::TObject* Sender);
	void __fastcall sbDeleteUserClick(System::TObject* Sender);
	void __fastcall PageControlChange(System::TObject* Sender);
	void __fastcall pcUsersChange(System::TObject* Sender);
	void __fastcall btnChangePasswordClick(System::TObject* Sender);
	void __fastcall tsProfilesDataEnter(System::TObject* Sender);
	void __fastcall cbxMUST_CHANGE_PWDClick(System::TObject* Sender);
	void __fastcall sbNewProfileClick(System::TObject* Sender);
	void __fastcall tsProfilesDataExit(System::TObject* Sender);
	void __fastcall sbChangeProfileDataClick(System::TObject* Sender);
	void __fastcall sbDeleteProfileClick(System::TObject* Sender);
	void __fastcall sbExitClick(System::TObject* Sender);
	void __fastcall CompListMouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState 
		Shift, int X, int Y);
	void __fastcall tsProgramsEnter(System::TObject* Sender);
	void __fastcall pcProgramsChange(System::TObject* Sender);
	void __fastcall tsProgramsExit(System::TObject* Sender);
	void __fastcall FormCloseQuery(System::TObject* Sender, bool &CanClose);
	void __fastcall sbRestoreProfileClick(System::TObject* Sender);
	void __fastcall sbApplyClick(System::TObject* Sender);
	void __fastcall sbRestoreClick(System::TObject* Sender);
	void __fastcall sbProfileAccessClick(System::TObject* Sender);
	void __fastcall tsUsersListEnter(System::TObject* Sender);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall dtpkInicioPChange(System::TObject* Sender);
	void __fastcall pcAuditEnter(System::TObject* Sender);
	void __fastcall pcAuditExit(System::TObject* Sender);
	void __fastcall pcAuditChange(System::TObject* Sender);
	void __fastcall sbDeleteAuditProgClick(System::TObject* Sender);
	void __fastcall sbDeleteAuditUserClick(System::TObject* Sender);
	void __fastcall DBNavigator2Click(System::TObject* Sender, Dbctrls::TNavigateBtn Button);
	void __fastcall DBNavigator2BeforeAction(System::TObject* Sender, Dbctrls::TNavigateBtn Button);
	void __fastcall dblkFormsCloseUp(System::TObject* Sender);
	void __fastcall CompListDeletion(System::TObject* Sender, Comctrls::TTreeNode* Node);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall dtpkInicioLTChange(System::TObject* Sender);
	void __fastcall sbDeleteUserLoginActivityClick(System::TObject* Sender);
	void __fastcall dblkForms2CloseUp(System::TObject* Sender);
	void __fastcall dblkForms1Click(System::TObject* Sender);
	void __fastcall dblkForms2Click(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall AllEnabledClick(System::TObject* Sender);
	void __fastcall ShowLegendaClick(System::TObject* Sender);
	void __fastcall btnLegendaClick(System::TObject* Sender);
	void __fastcall btnRefreshCurrentUsersClick(System::TObject* Sender);
	void __fastcall sbPrintUserListClick(System::TObject* Sender);
	void __fastcall sbPrintProfileListClick(System::TObject* Sender);
	void __fastcall sbPrintUserLoginActivityClick(System::TObject* Sender);
	void __fastcall sbPrintUserActivityClick(System::TObject* Sender);
	void __fastcall sbPrintCompUtilizationClick(System::TObject* Sender);
	void __fastcall PrintPermissionsClick(System::TObject* Sender);
	void __fastcall sbPrintUserAccessClick(System::TObject* Sender);
	void __fastcall sbPrintProfileAccessClick(System::TObject* Sender);
	void __fastcall tabAdditionalInfoEnter(System::TObject* Sender);
	void __fastcall tabAdditionalInfoExit(System::TObject* Sender);
	void __fastcall DBDateTimePicker1Change(System::TObject* Sender);
	
private:
	Users_basic::TUsersBasic* SecurityComponent;
	void __fastcall MontaAcessoUsuario(int USER_ID);
	void __fastcall MontaAcessoPerfil(int PROF_ID);
	void __fastcall DataChange(System::TObject* Sender, Db::TField* Field);
	void __fastcall GetActualUserId(int &User_Id);
	AnsiString __fastcall TreeViewToText(Comctrls::TTreeNodes* Items);
	
public:
	AnsiString __fastcall PermissionsToText(int FORM_ID);
	void __fastcall Call(Users_basic::TUsersBasic* theSecurityComponent);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TUserAdministration(Classes::TComponent* AOwner)
		 : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TUserAdministration(Classes::TComponent* AOwner
		, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TUserAdministration(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TUserAdministration(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TUserAdministration* UserAdministration;
extern PACKAGE void __fastcall ExecUsersAdm(Users_basic::TUsersBasic* theSecurityComponent);

}	/* namespace User_adm */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace User_adm;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// user_adm
