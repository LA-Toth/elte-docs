// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'users_sac.pas' rev: 5.00

#ifndef users_sacHPP
#define users_sacHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ImgList.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Users_sac
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TSecurityAdministrationCentral;
class PASCALIMPLEMENTATION TSecurityAdministrationCentral : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel1;
	Comctrls::TTreeView* TreeView;
	Dbtables::TQuery* qryApplications;
	Db::TStringField* qryApplicationsAPP_KEY;
	Stdctrls::TStaticText* StaticText1;
	Stdctrls::TButton* Button1;
	Stdctrls::TButton* Button2;
	Controls::TImageList* ImageList1;
	void __fastcall FormActivate(System::TObject* Sender);
	
public:
	AnsiString __fastcall Execute(Classes::TComponent* Database);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TSecurityAdministrationCentral(Classes::TComponent* 
		AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TSecurityAdministrationCentral(Classes::TComponent* 
		AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TSecurityAdministrationCentral(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TSecurityAdministrationCentral(HWND ParentWindow
		) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TSecurityAdministrationCentral* SecurityAdministrationCentral;

}	/* namespace Users_sac */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Users_sac;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// users_sac
