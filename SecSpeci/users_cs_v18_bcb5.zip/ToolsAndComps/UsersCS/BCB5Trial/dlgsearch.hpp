// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DlgSearch.pas' rev: 5.00

#ifndef DlgSearchHPP
#define DlgSearchHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <DBGrids.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dlgsearch
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfDlgSearch;
class PASCALIMPLEMENTATION TfDlgSearch : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Db::TDataSource* DataSource;
	Extctrls::TPanel* Panel1;
	Extctrls::TPanel* Panel2;
	Dbgrids::TDBGrid* DBGrid;
	Stdctrls::TEdit* edtSearch;
	Buttons::TBitBtn* BitBtn1;
	void __fastcall edtSearchChange(System::TObject* Sender);
	void __fastcall FormActivate(System::TObject* Sender);
	
public:
	AnsiString DlgCaption;
	AnsiString SearchField;
	AnsiString FieldTitle;
	AnsiString ResultField;
	Db::TDataSet* Dataset;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfDlgSearch(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfDlgSearch(Classes::TComponent* AOwner, int 
		Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfDlgSearch(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfDlgSearch(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Variant __fastcall Search(AnsiString aDlgCaption, AnsiString aSearchField, AnsiString 
	aFieldTitle, AnsiString aResultField, Db::TDataSet* aDataset);

}	/* namespace Dlgsearch */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dlgsearch;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DlgSearch
