// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'dtm_login.pas' rev: 5.00

#ifndef dtm_loginHPP
#define dtm_loginHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <DBTables.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dtm_login
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUserLogin;
class PASCALIMPLEMENTATION TUserLogin : public Forms::TDataModule 
{
	typedef Forms::TDataModule inherited;
	
__published:
	Dbtables::TQuery* qryPwdHistory;
	Dbtables::TQuery* qryAux;
	Dbtables::TQuery* qryUserInfo;
	Db::TStringField* qryUserInfoAPP_KEY;
	Db::TFloatField* qryUserInfoUSER_ID;
	Db::TFloatField* qryUserInfoEXPIRATION_DATE;
	Db::TStringField* qryUserInfoUSER_EXPIRE;
	Db::TStringField* qryUserInfoUSER_ACTIVE;
	Db::TStringField* qryUserInfoUSER_IS_ADMIN;
	Dbtables::TQuery* qryForm;
	Db::TStringField* qryFormFORM_NAME;
	Db::TFloatField* qryFormFORM_ID;
	Db::TStringField* qryFormFORM_CAPTION;
	Db::TStringField* qryFormAPP_KEY;
	Dbtables::TQuery* qryComps;
	Db::TStringField* qryCompsAPP_KEY;
	Db::TFloatField* qryCompsFORM_ID;
	Db::TStringField* qryCompsCOMP_NAME;
	Db::TFloatField* qryCompsCOMP_ID;
	Db::TStringField* qryCompsCOMP_CAPTION;
	Db::TFloatField* qryCompsPARENT_ID;
	Db::TDataSource* dtsForm;
	Dbtables::TQuery* qryUAccess;
	Db::TStringField* qryUAccessAPP_KEY;
	Db::TFloatField* qryUAccessFORM_ID;
	Db::TFloatField* qryUAccessCOMP_ID;
	Db::TFloatField* qryUAccessUSER_ID;
	Db::TStringField* qryUAccessAUTHORIZED;
	Dbtables::TQuery* qryLoginTrace;
	Db::TStringField* qryLoginTraceAPP_KEY;
	Db::TFloatField* qryLoginTraceUSER_ID;
	Db::TFloatField* qryLoginTraceLOGIN_DATE_TIME;
	Db::TFloatField* qryLoginTraceLOGOUT_DATE_TIME;
	Db::TStringField* qryLoginTraceCOMPUTER_NAME;
	Dbtables::TQuery* qryComp;
	Dbtables::TQuery* qryAudit;
	Dbtables::TQuery* qryUser;
	Dbtables::TQuery* qryProfile;
	Db::TStringField* qryUserInfoADDITIONAL_INFO;
	Dbtables::TQuery* qryVerifyMultipleLogin;
	Dbtables::TQuery* qryApplication;
	Db::TStringField* qryApplicationAPP_KEY;
	Db::TFloatField* qryApplicationTIME_OUT;
	Db::TFloatField* qryApplicationMAX_BAD_LOGINS;
	Db::TFloatField* qryApplicationMAX_DAYS_INNATIVE;
	Db::TStringField* qryApplicationDISABLE_USER;
	Db::TFloatField* qryApplicationMAX_PWD_HISTORY;
	Db::TStringField* qryApplicationALLOW_MULTIPLE_LOGINS;
	Dbtables::TQuery* qryVerifyDaysInnactive;
	Db::TFloatField* qryVerifyDaysInnactiveUSER_ID;
	Db::TFloatField* qryVerifyDaysInnactiveLAST_LOGOUT_DATE;
	Dbtables::TQuery* qryCurrentUsers;
	
public:
	void __fastcall ChangeFileNames(bool Use83DOS);
	void __fastcall SetDatabaseComponent(Classes::TComponent* Database);
	void __fastcall CloseAllDataset(void);
public:
	#pragma option push -w-inl
	/* TDataModule.Create */ inline __fastcall virtual TUserLogin(Classes::TComponent* AOwner) : Forms::TDataModule(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TDataModule.CreateNew */ inline __fastcall virtual TUserLogin(Classes::TComponent* AOwner, int Dummy
		) : Forms::TDataModule(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TDataModule.Destroy */ inline __fastcall virtual ~TUserLogin(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TUserLogin* UserLogin;

}	/* namespace Dtm_login */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dtm_login;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// dtm_login
