// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rpt_prof_list.pas' rev: 5.00

#ifndef rpt_prof_listHPP
#define rpt_prof_listHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <QuickRpt.hpp>	// Pascal unit
#include <Qrctrls.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rpt_prof_list
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS Trpt_ProfList;
class PASCALIMPLEMENTATION Trpt_ProfList : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Quickrpt::TQuickRep* QuickRep;
	Quickrpt::TQRBand* DetailBand1;
	Quickrpt::TQRBand* PageFooterBand1;
	Quickrpt::TQRBand* TitleBand1;
	Qrctrls::TQRSysData* QRSysData1;
	Quickrpt::TQRBand* ColumnHeaderBand1;
	Qrctrls::TQRLabel* qrlProfName;
	Qrctrls::TQRLabel* qrlInterval;
	Qrctrls::TQRLabel* qrlMustChangePwd;
	Qrctrls::TQRLabel* qrlAuditMode;
	Qrctrls::TQRDBText* QRDBText1;
	Qrctrls::TQRDBText* QRDBText3;
	Qrctrls::TQRDBText* QRDBText4;
	Qrctrls::TQRDBText* QRDBText6;
	Qrctrls::TQRSysData* qrsData;
	void __fastcall QRDBText4Print(System::TObject* sender, AnsiString &Value);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual Trpt_ProfList(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual Trpt_ProfList(Classes::TComponent* AOwner, int 
		Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~Trpt_ProfList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall Trpt_ProfList(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Trpt_ProfList* rpt_ProfList;

}	/* namespace Rpt_prof_list */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Rpt_prof_list;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rpt_prof_list
